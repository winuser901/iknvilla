<?php
/**
 * Authentication helper
 *
 * Contains utility functions for managing user sessions, fetching the
 * currently authenticated user and protecting routes that require
 * authentication or specific roles.
 */

if (!function_exists('is_logged_in')) {
    /**
     * Determine whether the current visitor has an active session.
     *
     * @return bool
     */
    function is_logged_in(): bool
    {
        return isset($_SESSION['user_id']);
    }
}

if (!function_exists('current_user')) {
    /**
     * Retrieve the currently logged‑in user's record from the database.
     * Returns null when no user is logged in. The result is cached on
     * subsequent calls to avoid repeated queries.
     *
     * @return array|null
     */
    function current_user(): ?array
    {
        static $user;
        if (!is_logged_in()) {
            return null;
        }
        if ($user) {
            return $user;
        }
        require_once __DIR__ . '/../app/Models/UserModel.php';
        $model = new App\Models\UserModel();
        $user   = $model->find($_SESSION['user_id']);
        return $user;
    }
}

if (!function_exists('require_login')) {
    /**
     * Redirect to the login page if the visitor is not authenticated.
     * Optionally accepts a redirect URL to return to after login.
     *
     * @param string $redirectAfter
     */
    function require_login(string $redirectAfter = '/login'): void
    {
        if (!is_logged_in()) {
            header('Location: ' . base_url(trim($redirectAfter, '/')));
            exit;
        }
    }
}

if (!function_exists('require_role')) {
    /**
     * Ensure that the current user has the specified role. If they do
     * not, redirect them to the dashboard or login page. This is used
     * to protect admin routes.
     *
     * @param string $role Required role (e.g. 'admin')
     */
    function require_role(string $role): void
    {
        $user = current_user();
        if (!$user || $user['role'] !== $role) {
            // Insufficient privileges – redirect to home
            header('Location: ' . base_url());
            exit;
        }
    }
}