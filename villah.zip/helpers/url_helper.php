<?php
/**
 * URL Helper
 *
 * Contains functions to assist with generating absolute URLs based on the
 * application configuration. Useful for linking to assets or routes.
 */

if (!function_exists('base_url')) {
    /**
     * Generate an absolute URL from a relative URI. Reads the base_url
     * configuration from config/config.php. If the URI starts with
     * http/https it will be returned unchanged.
     *
     * @param string $uri
     *
     * @return string
     */
    function base_url(string $uri = ''): string
    {
        // If the URI is already absolute simply return it
        if (preg_match('#^https?://#', $uri)) {
            return $uri;
        }
        static $config;
        if (!$config) {
            $config = require __DIR__ . '/../config/config.php';
        }
        $base = rtrim($config['base_url'], '/');
        $uri  = ltrim($uri, '/');
        return $base . '/' . $uri;
    }
}