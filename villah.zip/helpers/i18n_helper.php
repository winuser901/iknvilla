<?php
/**
 * Internationalization helper
 *
 * Provides functions for retrieving translation strings based on the current
 * locale. The current locale is stored in $_SESSION['lang'] and falls
 * back to the default_language configured in config/config.php. If a
 * translation key does not exist the key itself will be returned.
 */

if (!function_exists('lang')) {
    /**
     * Retrieve a translated string by key.
     *
     * @param string $key
     *
     * @return string
     */
    function lang(string $key): string
    {
        static $translations;
        static $loadedLocale;
        // Determine current locale
        $config = require __DIR__ . '/../config/config.php';
        $locale = $_SESSION['lang'] ?? $config['default_language'];
        if (!in_array($locale, $config['supported_languages'], true)) {
            $locale = $config['default_language'];
        }
        // Load translations if not loaded or locale changed
        if (!$translations || $loadedLocale !== $locale) {
            $file = __DIR__ . '/../app/Language/' . $locale . '/messages.php';
            $translations = file_exists($file) ? require $file : [];
            $loadedLocale = $locale;
        }
        return $translations[$key] ?? $key;
    }
}