<?php
namespace App\Models;

use Model;

/**
 * PaymentModel
 *
 * Records payments uploaded by users and approved by administrators. It
 * provides helpers to insert new payment records and update their
 * verification status. When approving a payment this model also
 * updates the associated booking's payment_status and amount_paid/remaining.
 */
class PaymentModel extends Model
{
    protected $table = 'payments';
    protected $primaryKey = 'id';

    /**
     * Create a new payment record. Returns the insert ID on success.
     *
     * @param int    $bookingId
     * @param int    $step          Payment step (1 for first, 2 for second)
     * @param string $method        bank_transfer or qris
     * @param float  $amount
     * @param string $proofImage    Path to uploaded proof file
     *
     * @return int
     */
    public function createPayment(int $bookingId, int $step, string $method, float $amount, string $proofImage): int
    {
        $data = [
            'booking_id'  => $bookingId,
            'payment_step'=> $step,
            'method'      => $method,
            'amount'      => $amount,
            'proof_image' => $proofImage,
            'paid_at'     => date('Y-m-d H:i:s'),
            'verification_status' => 'PENDING',
            'created_at'  => date('Y-m-d H:i:s'),
            'updated_at'  => date('Y-m-d H:i:s'),
        ];
        return $this->insert($data);
    }

    /**
     * Verify or reject a payment. Updates booking status accordingly.
     *
     * @param int    $paymentId
     * @param string $status   APPROVED or REJECTED
     * @param int    $adminId  ID of verifying admin
     *
     * @return bool
     */
    public function verify(int $paymentId, string $status, int $adminId): bool
    {
        $payment = $this->find($paymentId);
        if (!$payment) {
            return false;
        }
        // Update payment verification
        $this->update($paymentId, [
            'verification_status' => $status,
            'verified_by'         => $adminId,
            'updated_at'          => date('Y-m-d H:i:s'),
        ]);
        // If rejected no further action required
        if ($status !== 'APPROVED') {
            return true;
        }
        // Fetch booking
        require_once __DIR__ . '/BookingModel.php';
        $bookingModel = new BookingModel();
        $booking = $bookingModel->find($payment['booking_id']);
        if (!$booking) {
            return false;
        }
        // Update booking payment amounts
        $newAmountPaid = $payment['amount'] + $booking['amount_paid_now'];
        $remaining = $booking['grand_total'] - $newAmountPaid;
        $paymentStatus = $remaining <= 0.01 ? 'PAID' : 'PARTIAL';
        $bookingStatus = ($paymentStatus === 'PAID') ? 'CONFIRMED' : $booking['booking_status'];
        $bookingModel->update($booking['id'], [
            'amount_paid_now'  => $newAmountPaid,
            'amount_remaining' => max($remaining, 0),
            'payment_status'   => $paymentStatus,
            'booking_status'   => $bookingStatus,
        ]);
        return true;
    }
}