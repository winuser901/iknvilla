<?php
namespace App\Models;

use Model;

/**
 * VillaModel
 *
 * Provides data access functions for villas. In addition to the
 * generic CRUD methods inherited from Model this class includes
 * helpers for retrieving active villas, looking up a villa by its
 * slug, and performing simple searches.
 */
class VillaModel extends Model
{
    protected $table = 'villas';
    protected $primaryKey = 'id';

    /**
     * Retrieve all active villas. Optionally limit the result and order
     * by creation date.
     *
     * @param int $limit
     * @return array
     */
    public function getActive(int $limit = 0): array
    {
        return $this->findAll(['status' => 'active'], 'created_at DESC', $limit);
    }

    /**
     * Find a villa by its slug. Returns null if not found.
     *
     * @param string $slug
     * @return array|null
     */
    public function getBySlug(string $slug): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE slug = :slug LIMIT 1";
        $stmt = $this->query($sql, ['slug' => $slug]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    /**
     * Search villas by city or keyword in name. This is a simple example
     * demonstrating how filters could be implemented. For production
     * systems consider full‑text indexing for better performance.
     *
     * @param string|null $city
     * @param string|null $keyword
     * @return array
     */
    public function search(?string $city = null, ?string $keyword = null): array
    {
        $sql = "SELECT * FROM {$this->table} WHERE status = 'active'";
        $params = [];
        if ($city) {
            $sql .= " AND city = :city";
            $params['city'] = $city;
        }
        if ($keyword) {
            $sql .= " AND (name_id LIKE :kw OR name_en LIKE :kw)";
            $params['kw'] = '%' . $keyword . '%';
        }
        $sql .= ' ORDER BY created_at DESC';
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }

    /**
     * Retrieve a list of top villas. Currently this simply returns
     * the most recently created active villas but could be extended
     * to use booking counts or ratings to determine popularity.
     *
     * @param int $limit
     * @return array
     */
    public function getPopular(int $limit = 3): array
    {
        return $this->findAll(['status' => 'active'], 'created_at DESC', $limit);
    }
}