<?php
namespace App\Models;

use Model;

/**
 * UserModel
 *
 * Handles CRUD operations for the users table. Provides helper
 * functions for authentication tasks such as finding users by email
 * and verifying passwords. Extends the base Model class which
 * encapsulates PDO access.
 */
class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';

    /**
     * Find a user record by email address.
     *
     * @param string $email
     *
     * @return array|null
     */
    public function findByEmail(string $email): ?array
    {
        $sql  = "SELECT * FROM {$this->table} WHERE email = :email LIMIT 1";
        $stmt = $this->query($sql, ['email' => $email]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    /**
     * Insert a new user. Expects the password to be pre‑hashed. Returns the
     * insert ID.
     *
     * @param array $data
     *
     * @return int
     */
    public function create(array $data): int
    {
        return $this->insert($data);
    }
}