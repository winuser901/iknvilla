<?php
namespace App\Models;

use Model;

/**
 * VillaImageModel
 *
 * Fetches images associated with villas.
 */
class VillaImageModel extends Model
{
    protected $table = 'villa_images';
    protected $primaryKey = 'id';

    public function getByVilla(int $villaId): array
    {
        $sql = "SELECT * FROM {$this->table} WHERE villa_id = :id";
        $stmt = $this->query($sql, ['id' => $villaId]);
        return $stmt->fetchAll();
    }
}