<?php
namespace App\Models;

use Model;
use App\Models\VillaModel;
use App\Models\PackageModel;
use App\Models\DiscountRuleModel;
use App\Models\PromoCodeModel;

/**
 * BookingModel
 *
 * Handles creation of bookings and encapsulates the pricing logic
 * including calculation of base price, application of automatic
 * discounts and promo codes, and computation of payment schedules.
 */
class BookingModel extends Model
{
    protected $table = 'bookings';
    protected $primaryKey = 'id';

    /**
     * Generate a unique human‑readable booking code consisting of
     * uppercase letters and numbers. Checks the database to avoid
     * collisions.
     *
     * @return string
     */
    protected function generateBookingCode(): string
    {
        do {
            $code = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
            $sql  = "SELECT COUNT(*) AS count FROM {$this->table} WHERE booking_code = :code";
            $stmt = $this->query($sql, ['code' => $code]);
            $exists = $stmt->fetch()['count'] > 0;
        } while ($exists);
        return $code;
    }

    /**
     * Create a new booking record along with all pricing calculations. The
     * paymentOption parameter must match a key defined in
     * config['payment_options'] (e.g. FULL, DP75, DP50). Returns an
     * array containing the booking record or null on failure.
     *
     * @param int    $userId
     * @param string $type      'villa' or 'package'
     * @param int    $referenceId
     * @param string $startDate YYYY-MM-DD
     * @param string|null $endDate   YYYY-MM-DD (null for package)
     * @param int    $participants Number of guests or participants
     * @param string $paymentOption
     * @param string|null $promoCode
     *
     * @return array|null
     */
    public function createBooking(
        int $userId,
        string $type,
        int $referenceId,
        string $startDate,
        ?string $endDate,
        int $participants,
        string $paymentOption,
        ?string $promoCode = null
    ): ?array {
        // Load config for payment multipliers
        $config = require __DIR__ . '/../../config/config.php';
        $paymentOptions = $config['payment_options'];
        if (!isset($paymentOptions[$paymentOption])) {
            throw new \InvalidArgumentException('Invalid payment option');
        }
        // Determine base price based on type
        $subtotal = 0.0;
        if ($type === 'villa') {
            $villaModel = new VillaModel();
            $villa = $villaModel->find($referenceId);
            if (!$villa) {
                return null;
            }
            // Calculate nights (at least 1 night)
            $start  = new \DateTime($startDate);
            $end    = new \DateTime($endDate);
            $nights = (int)$start->diff($end)->format('%a');
            $nights = max($nights, 1);
            $subtotal = $villa['base_price_per_night'] * $nights;
        } elseif ($type === 'package') {
            $packageModel = new PackageModel();
            $package = $packageModel->find($referenceId);
            if (!$package) {
                return null;
            }
            $subtotal = $package['base_price_per_person'] * $participants;
        } else {
            throw new \InvalidArgumentException('Unknown booking type');
        }
        // Apply automatic discounts
        $discountRuleModel = new DiscountRuleModel();
        $autoDiscount = $discountRuleModel->calculate($startDate, $subtotal);
        // Apply promo code
        $promoDiscountAmount = 0.0;
        $promoId = null;
        if ($promoCode) {
            $promoModel = new PromoCodeModel();
            $promo = $promoModel->validateCode($promoCode, $subtotal - $autoDiscount['total'], $type);
            if ($promo) {
                $promoDiscountAmount = $promo['discount'];
                $promoId = $promo['id'];
                // Increment usage later after insertion
            }
        }
        // Compute totals
        $discountAmount = $autoDiscount['total'] + $promoDiscountAmount;
        if ($discountAmount > $subtotal) {
            $discountAmount = $subtotal;
        }
        $grandTotal = $subtotal - $discountAmount;
        // Payment schedule
        $percentage  = $paymentOptions[$paymentOption];
        $amountPaidNow = $grandTotal * $percentage;
        $amountRemaining = $grandTotal - $amountPaidNow;
        // Determine due date for remaining payment: set to 7 days before start
        $dueDateRemaining = null;
        if ($amountRemaining > 0) {
            $due = new \DateTime($startDate);
            $due->modify('-7 days');
            $dueDateRemaining = $due->format('Y-m-d');
        }
        // Generate unique booking code
        $bookingCode = $this->generateBookingCode();
        // Prepare data for insertion
        $data = [
            'booking_code'     => $bookingCode,
            'user_id'          => $userId,
            'type'             => $type,
            'reference_id'     => $referenceId,
            'start_date'       => $startDate,
            'end_date'         => $endDate,
            'participants'     => $participants,
            'subtotal'         => $subtotal,
            'discount_amount'  => $discountAmount,
            'grand_total'      => $grandTotal,
            'payment_option'   => $paymentOption,
            'amount_paid_now'  => $amountPaidNow,
            'amount_remaining' => $amountRemaining,
            'due_date_remaining' => $dueDateRemaining,
            'payment_status'   => ($amountPaidNow >= $grandTotal) ? 'PAID' : 'UNPAID',
            'booking_status'   => 'PENDING_CONFIRMATION',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s'),
        ];
        // Insert into bookings
        $bookingId = $this->insert($data);
        if (!$bookingId) {
            return null;
        }
        // If promo used, increment usage
        if ($promoId) {
            $promoModel = new PromoCodeModel();
            $promoModel->incrementUsage($promoId);
        }
        // Return booking record
        return $this->find($bookingId);
    }
}