<?php
namespace App\Models;

use Model;

/**
 * PackageImageModel
 *
 * Fetches images associated with packages.
 */
class PackageImageModel extends Model
{
    protected $table = 'package_images';
    protected $primaryKey = 'id';

    public function getByPackage(int $packageId): array
    {
        $sql = "SELECT * FROM {$this->table} WHERE package_id = :id";
        $stmt = $this->query($sql, ['id' => $packageId]);
        return $stmt->fetchAll();
    }
}