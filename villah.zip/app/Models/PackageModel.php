<?php
namespace App\Models;

use Model;

/**
 * PackageModel
 *
 * Similar to VillaModel but for holiday packages. Provides
 * convenience methods for retrieving active packages, looking up
 * packages by slug and selecting popular entries.
 */
class PackageModel extends Model
{
    protected $table = 'packages';
    protected $primaryKey = 'id';

    public function getActive(int $limit = 0): array
    {
        return $this->findAll(['status' => 'active'], 'created_at DESC', $limit);
    }

    public function getBySlug(string $slug): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE slug = :slug LIMIT 1";
        $stmt = $this->query($sql, ['slug' => $slug]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    public function getPopular(int $limit = 3): array
    {
        return $this->findAll(['status' => 'active'], 'created_at DESC', $limit);
    }
}