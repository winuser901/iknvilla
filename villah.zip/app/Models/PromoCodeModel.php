<?php
namespace App\Models;

use Model;

/**
 * PromoCodeModel
 *
 * Handles operations related to promo codes including validation and
 * calculating discounts based on the code. When a code is used
 * successfully the used_count is incremented. Codes can be limited by
 * date range, minimum order amount, usage count and type (villa or
 * package). Discount types supported are percentage and fixed.
 */
class PromoCodeModel extends Model
{
    protected $table = 'promo_codes';
    protected $primaryKey = 'id';

    /**
     * Validate a promo code against the current order.
     *
     * @param string $code        The code provided by the customer
     * @param float  $orderAmount The subtotal of the order
     * @param string $type        'villa' or 'package'
     *
     * @return array|null Returns an array with discount amount and a
     *                     message if valid, or null if invalid.
     */
    public function validateCode(string $code, float $orderAmount, string $type): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE code = :code AND status = 'active' LIMIT 1";
        $stmt = $this->query($sql, ['code' => strtoupper($code)]);
        $promo = $stmt->fetch();
        if (!$promo) {
            return null;
        }
        $today = date('Y-m-d');
        // Check date validity
        if ($today < $promo['valid_from'] || $today > $promo['valid_until']) {
            return null;
        }
        // Check min order amount
        if ($orderAmount < (float)$promo['min_order_amount']) {
            return null;
        }
        // Check usage limit
        if ($promo['max_uses'] > 0 && $promo['used_count'] >= $promo['max_uses']) {
            return null;
        }
        // Check applicable type
        if ($promo['applicable_to'] !== 'both' && $promo['applicable_to'] !== $type) {
            return null;
        }
        // Calculate discount
        $discount = 0.0;
        if ($promo['discount_type'] === 'PERCENT') {
            $discount = $orderAmount * ((float)$promo['value'] / 100.0);
        } else {
            $discount = (float)$promo['value'];
        }
        // Cap discount at order amount to prevent negative totals
        if ($discount > $orderAmount) {
            $discount = $orderAmount;
        }
        // All checks passed – return details
        return [
            'id'      => $promo['id'],
            'code'    => $promo['code'],
            'discount'=> $discount,
            'type'    => $promo['discount_type'],
            'value'   => $promo['value'],
            'message' => '',
        ];
    }

    /**
     * Increment the usage count for a promo code. Should be called
     * immediately after a code has been successfully applied to prevent
     * over‑use. Returns the number of affected rows.
     *
     * @param int $id
     *
     * @return int
     */
    public function incrementUsage(int $id): int
    {
        $sql = "UPDATE {$this->table} SET used_count = used_count + 1 WHERE id = :id";
        $stmt = $this->query($sql, ['id' => $id]);
        return $stmt->rowCount();
    }
}