<?php
namespace App\Models;

use Model;

/**
 * DiscountRuleModel
 *
 * Provides access to automatic discount rules such as early bird and
 * last minute promotions. When calculating discounts for a booking
 * this model determines which rules apply based on the number of days
 * between the current date and the booking start date.
 */
class DiscountRuleModel extends Model
{
    protected $table = 'discount_rules';
    protected $primaryKey = 'id';

    /**
     * Compute the discount for a given booking based on active rules.
     * Returns an array containing the total discount amount and
     * individual rule descriptions. The startDate parameter should be
     * provided in YYYY‑MM‑DD format. Only rules with status = 'active'
     * are considered.
     *
     * @param string $startDate
     * @param float  $subtotal
     *
     * @return array ['total' => float, 'items' => array]
     */
    public function calculate(string $startDate, float $subtotal): array
    {
        $today = new \DateTime();
        $start = new \DateTime($startDate);
        $interval = (int)$today->diff($start)->format('%r%a'); // relative days
        $sql = "SELECT * FROM {$this->table} WHERE status = 'active'";
        $rules = $this->query($sql)->fetchAll();
        $totalDiscount = 0.0;
        $items = [];
        foreach ($rules as $rule) {
            $apply = false;
            if ($rule['type'] === 'early_bird' && $rule['days_before'] !== null) {
                if ($interval >= (int)$rule['days_before']) {
                    $apply = true;
                }
            } elseif ($rule['type'] === 'last_minute' && $rule['days_within'] !== null) {
                if ($interval <= (int)$rule['days_within']) {
                    $apply = true;
                }
            } elseif ($rule['type'] === 'seasonal') {
                // For simplicity, seasonal discounts always apply when active
                $apply = true;
            }
            if ($apply) {
                $discount = 0.0;
                if ($rule['discount_type'] === 'PERCENT') {
                    $discount = $subtotal * ((float)$rule['value'] / 100.0);
                } else {
                    $discount = (float)$rule['value'];
                }
                if ($discount > $subtotal) {
                    $discount = $subtotal;
                }
                $totalDiscount += $discount;
                $items[] = [
                    'rule'      => $rule['rule_name'],
                    'discount'  => $discount,
                    'type'      => $rule['type'],
                    'value'     => $rule['value'],
                    'valueType' => $rule['discount_type'],
                ];
            }
        }
        // Cap total discount at subtotal
        if ($totalDiscount > $subtotal) {
            $totalDiscount = $subtotal;
        }
        return ['total' => $totalDiscount, 'items' => $items];
    }
}