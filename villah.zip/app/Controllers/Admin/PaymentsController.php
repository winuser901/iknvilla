<?php
namespace App\Controllers\Admin;

use Controller;
use App\Models\PaymentModel;
use App\Models\BookingModel;

/**
 * Admin\PaymentsController
 *
 * Allows administrators to review uploaded payment proofs and approve
 * or reject them. Approving a payment updates the booking's payment
 * status automatically.
 */
class PaymentsController extends Controller
{
    public function index(): void
    {
        require_role('admin');
        $model = new PaymentModel();
        $sql = "SELECT * FROM payments ORDER BY created_at DESC";
        $stmt = $model->query($sql);
        $payments = $stmt->fetchAll();
        // Attach booking code
        $bookingModel = new BookingModel();
        foreach ($payments as &$p) {
            $bk = $bookingModel->find($p['booking_id']);
            $p['booking_code'] = $bk['booking_code'] ?? '';
        }
        $this->render('admin/payments_list', [
            'payments' => $payments,
        ], 'admin');
    }

    /**
     * Verify or reject a payment. Status must be APPROVED or REJECTED.
     * After updating the payment record and booking, the user is
     * redirected back to the payments list.
     *
     * @param int    $id
     * @param string $action
     */
    public function verify(int $id, string $action): void
    {
        require_role('admin');
        $status = strtoupper($action);
        if (!in_array($status, ['APPROVED','REJECTED'], true)) {
            $this->redirect('/admin/payments');
            return;
        }
        $model = new PaymentModel();
        $adminId = $_SESSION['user_id'];
        $model->verify($id, $status, $adminId);
        $this->redirect('/admin/payments');
    }
}