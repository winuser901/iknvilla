<?php
namespace App\Controllers\Admin;

use Controller;
use App\Models\PromoCodeModel;

/**
 * Admin PromoCodesController
 *
 * Manage promo codes for discounts.
 */
class PromoCodesController extends Controller
{
    public function index(): void
    {
        require_role('admin');
        $model = new PromoCodeModel();
        $promoCodes = $model->findAll([], 'id DESC');
        $this->render('admin/promocodes_list', ['promoCodes' => $promoCodes], 'admin');
    }

    public function createForm(): void
    {
        require_role('admin');
        $this->render('admin/promocode_form', ['code' => null], 'admin');
    }

    public function create(): void
    {
        require_role('admin');
        $model = new PromoCodeModel();
        $data = [
            'code' => trim($_POST['code'] ?? ''),
            'description_id' => trim($_POST['description_id'] ?? ''),
            'description_en' => trim($_POST['description_en'] ?? ''),
            'discount_type' => $_POST['discount_type'] ?? 'PERCENT',
            'value' => (float)($_POST['value'] ?? 0),
            'max_uses' => (int)($_POST['max_uses'] ?? 0),
            'valid_from' => $_POST['valid_from'] ?? date('Y-m-d'),
            'valid_until' => $_POST['valid_until'] ?? date('Y-m-d'),
            'min_order_amount' => (float)($_POST['min_order_amount'] ?? 0),
            'applicable_to' => $_POST['applicable_to'] ?? 'both',
            'status' => $_POST['status'] ?? 'active',
        ];
        $model->create($data);
        $this->redirect('/admin/promo-codes');
    }

    public function editForm(int $id): void
    {
        require_role('admin');
        $model = new PromoCodeModel();
        $code = $model->find($id);
        if (!$code) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Promo code not found.</p>';
            return;
        }
        $this->render('admin/promocode_form', ['code' => $code], 'admin');
    }

    public function update(int $id): void
    {
        require_role('admin');
        $model = new PromoCodeModel();
        $code = $model->find($id);
        if (!$code) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Promo code not found.</p>';
            return;
        }
        $data = [
            'code' => trim($_POST['code'] ?? $code['code']),
            'description_id' => trim($_POST['description_id'] ?? $code['description_id']),
            'description_en' => trim($_POST['description_en'] ?? $code['description_en']),
            'discount_type' => $_POST['discount_type'] ?? $code['discount_type'],
            'value' => (float)($_POST['value'] ?? $code['value']),
            'max_uses' => (int)($_POST['max_uses'] ?? $code['max_uses']),
            'valid_from' => $_POST['valid_from'] ?? $code['valid_from'],
            'valid_until' => $_POST['valid_until'] ?? $code['valid_until'],
            'min_order_amount' => (float)($_POST['min_order_amount'] ?? $code['min_order_amount']),
            'applicable_to' => $_POST['applicable_to'] ?? $code['applicable_to'],
            'status' => $_POST['status'] ?? $code['status'],
        ];
        $model->update($id, $data);
        $this->redirect('/admin/promo-codes');
    }

    public function delete(int $id): void
    {
        require_role('admin');
        $model = new PromoCodeModel();
        $model->delete($id);
        $this->redirect('/admin/promo-codes');
    }
}
