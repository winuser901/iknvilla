<?php
namespace App\Controllers\Admin;

use Controller;
use App\Models\VillaModel;
use App\Models\VillaImageModel;

/**
 * Admin\\VillasController
 *
 * Provides CRUD operations for villas. Only admin users may access.
 */
class VillasController extends Controller
{
    public function index(): void
    {
        require_role('admin');
        $model = new VillaModel();
        $villas = $model->findAll([], 'id DESC');
        $this->render('admin/villas_list', ['villas' => $villas], 'admin');
    }

    public function createForm(): void
    {
        require_role('admin');
        $this->render('admin/villa_form', ['villa' => null], 'admin');
    }

    public function create(): void
    {
        require_role('admin');
        $data = [
            'name_id' => trim($_POST['name_id'] ?? ''),
            'name_en' => trim($_POST['name_en'] ?? ''),
            'slug'    => strtolower(str_replace(' ', '-', trim($_POST['name_en'] ?? ''))),
            'location' => trim($_POST['location'] ?? ''),
            'city'     => trim($_POST['city'] ?? ''),
            'country'  => trim($_POST['country'] ?? 'Indonesia'),
            'max_guest'=> (int)($_POST['max_guest'] ?? 1),
            'base_price_per_night' => (float)($_POST['base_price_per_night'] ?? 0),
            'facilities' => trim($_POST['facilities'] ?? ''),
            'tags'       => trim($_POST['tags'] ?? ''),
            'description_id' => trim($_POST['description_id'] ?? ''),
            'description_en' => trim($_POST['description_en'] ?? ''),
            'status' => 'active',
        ];
        $model = new VillaModel();
        $villaId = $model->create($data);
        // handle image upload (single file for simplicity)
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['image'];
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $allowed = ['jpg','jpeg','png','webp'];
            if (in_array(strtolower($ext), $allowed, true)) {
                $dir = __DIR__ . '/../../../uploads/villas';
                if (!is_dir($dir)) {
                    mkdir($dir, 0777, true);
                }
                $filename = $villaId . '_' . time() . '.' . $ext;
                $target = $dir . '/' . $filename;
                move_uploaded_file($file['tmp_name'], $target);
                $imgModel = new VillaImageModel();
                $imgModel->create([
                    'villa_id' => $villaId,
                    'path' => 'uploads/villas/' . $filename,
                ]);
            }
        }
        $this->redirect('/admin/villas');
    }

    public function editForm(int $id): void
    {
        require_role('admin');
        $model = new VillaModel();
        $villa = $model->find($id);
        if (!$villa) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Villa not found.</p>';
            return;
        }
        $this->render('admin/villa_form', ['villa' => $villa], 'admin');
    }

    public function update(int $id): void
    {
        require_role('admin');
        $model = new VillaModel();
        $villa = $model->find($id);
        if (!$villa) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Villa not found.</p>';
            return;
        }
        $data = [
            'name_id' => trim($_POST['name_id'] ?? ''),
            'name_en' => trim($_POST['name_en'] ?? ''),
            'slug'    => strtolower(str_replace(' ', '-', trim($_POST['slug'] ?? $villa['slug']))),
            'location' => trim($_POST['location'] ?? ''),
            'city'     => trim($_POST['city'] ?? ''),
            'country'  => trim($_POST['country'] ?? ''),
            'max_guest'=> (int)($_POST['max_guest'] ?? $villa['max_guest']),
            'base_price_per_night' => (float)($_POST['base_price_per_night'] ?? $villa['base_price_per_night']),
            'facilities' => trim($_POST['facilities'] ?? ''),
            'tags'       => trim($_POST['tags'] ?? ''),
            'description_id' => trim($_POST['description_id'] ?? ''),
            'description_en' => trim($_POST['description_en'] ?? ''),
        ];
        $model->update($id, $data);
        // handle new image upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['image'];
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $allowed = ['jpg','jpeg','png','webp'];
            if (in_array(strtolower($ext), $allowed, true)) {
                $dir = __DIR__ . '/../../../uploads/villas';
                if (!is_dir($dir)) {
                    mkdir($dir, 0777, true);
                }
                $filename = $id . '_' . time() . '.' . $ext;
                $target = $dir . '/' . $filename;
                move_uploaded_file($file['tmp_name'], $target);
                $imgModel = new VillaImageModel();
                $imgModel->create([
                    'villa_id' => $id,
                    'path' => 'uploads/villas/' . $filename,
                ]);
            }
        }
        $this->redirect('/admin/villas');
    }

    public function delete(int $id): void
    {
        require_role('admin');
        $model = new VillaModel();
        $model->delete($id);
        $this->redirect('/admin/villas');
    }
}
