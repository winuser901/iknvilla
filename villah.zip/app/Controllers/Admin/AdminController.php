<?php
namespace App\Controllers\Admin;

use Controller;
use App\Models\UserModel;
use App\Models\BookingModel;

/**
 * AdminController
 *
 * Handles authentication for administrators and displays a simple
 * dashboard with key performance indicators. Only users with the
 * 'admin' role may access these pages.
 */
class AdminController extends Controller
{
    public function loginForm(): void
    {
        if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin') {
            $this->redirect('/admin/dashboard');
        }
        $this->render('admin/login', [], 'admin');
    }

    public function login(): void
    {
        $email = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $errors = [];
        if (!$email || !$password) {
            $errors[] = $this->t('Please enter email and password');
        } else {
            $model = new UserModel();
            $user = $model->findByEmail($email);
            if (!$user || $user['role'] !== 'admin' || !password_verify($password, $user['password_hash'])) {
                $errors[] = $this->t('Invalid credentials');
            } else {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role']    = $user['role'];
                $_SESSION['lang']    = $user['preferred_language'] ?? $this->config['default_language'];
                $this->redirect('/admin/dashboard');
                return;
            }
        }
        $this->render('admin/login', ['errors' => $errors], 'admin');
    }

    public function logout(): void
    {
        session_destroy();
        $this->redirect('/admin/login');
    }

    public function dashboard(): void
    {
        require_role('admin');
        // Simple KPIs: total bookings and total revenue
        $bookingModel = new BookingModel();
        $totalBookings = $bookingModel->query("SELECT COUNT(*) AS cnt FROM bookings", [])->fetch()['cnt'];
        $revenue = $bookingModel->query("SELECT SUM(amount_paid_now) AS total_paid FROM bookings", [])->fetch()['total_paid'] ?? 0;
        $this->render('admin/dashboard', [
            'totalBookings' => $totalBookings,
            'revenue'       => $revenue,
        ], 'admin');
    }
}