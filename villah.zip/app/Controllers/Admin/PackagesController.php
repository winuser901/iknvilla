<?php
namespace App\Controllers\Admin;

use Controller;
use App\Models\PackageModel;
use App\Models\PackageImageModel;

/**
 * Admin PackagesController
 *
 * CRUD operations for holiday packages.
 */
class PackagesController extends Controller
{
    public function index(): void
    {
        require_role('admin');
        $model = new PackageModel();
        $packages = $model->findAll([], 'id DESC');
        $this->render('admin/packages_list', ['packages' => $packages], 'admin');
    }

    public function createForm(): void
    {
        require_role('admin');
        $this->render('admin/package_form', ['package' => null], 'admin');
    }

    public function create(): void
    {
        require_role('admin');
        $data = [
            'name_id' => trim($_POST['name_id'] ?? ''),
            'name_en' => trim($_POST['name_en'] ?? ''),
            'slug'    => strtolower(str_replace(' ', '-', trim($_POST['name_en'] ?? ''))),
            'city'     => trim($_POST['city'] ?? ''),
            'duration_days' => (int)($_POST['duration_days'] ?? 1),
            'base_price_per_person' => (float)($_POST['base_price_per_person'] ?? 0),
            'min_people' => (int)($_POST['min_people'] ?? 1),
            'max_people' => (int)($_POST['max_people'] ?? 10),
            'itinerary'  => trim($_POST['itinerary'] ?? ''),
            'inclusions' => trim($_POST['inclusions'] ?? ''),
            'exclusions' => trim($_POST['exclusions'] ?? ''),
            'description_id' => trim($_POST['description_id'] ?? ''),
            'description_en' => trim($_POST['description_en'] ?? ''),
            'status' => 'active',
        ];
        $model = new PackageModel();
        $packageId = $model->create($data);
        // image upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['image'];
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $allowed = ['jpg','jpeg','png','webp'];
            if (in_array(strtolower($ext), $allowed, true)) {
                $dir = __DIR__ . '/../../../uploads/packages';
                if (!is_dir($dir)) {
                    mkdir($dir, 0777, true);
                }
                $filename = $packageId . '_' . time() . '.' . $ext;
                $target = $dir . '/' . $filename;
                move_uploaded_file($file['tmp_name'], $target);
                $imgModel = new PackageImageModel();
                $imgModel->create([
                    'package_id' => $packageId,
                    'path' => 'uploads/packages/' . $filename,
                ]);
            }
        }
        $this->redirect('/admin/packages');
    }

    public function editForm(int $id): void
    {
        require_role('admin');
        $model = new PackageModel();
        $package = $model->find($id);
        if (!$package) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Package not found.</p>';
            return;
        }
        $this->render('admin/package_form', ['package' => $package], 'admin');
    }

    public function update(int $id): void
    {
        require_role('admin');
        $model = new PackageModel();
        $package = $model->find($id);
        if (!$package) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Package not found.</p>';
            return;
        }
        $data = [
            'name_id' => trim($_POST['name_id'] ?? ''),
            'name_en' => trim($_POST['name_en'] ?? ''),
            'slug'    => strtolower(str_replace(' ', '-', trim($_POST['slug'] ?? $package['slug']))),
            'city'     => trim($_POST['city'] ?? ''),
            'duration_days' => (int)($_POST['duration_days'] ?? $package['duration_days']),
            'base_price_per_person' => (float)($_POST['base_price_per_person'] ?? $package['base_price_per_person']),
            'min_people' => (int)($_POST['min_people'] ?? $package['min_people']),
            'max_people' => (int)($_POST['max_people'] ?? $package['max_people']),
            'itinerary'  => trim($_POST['itinerary'] ?? ''),
            'inclusions' => trim($_POST['inclusions'] ?? ''),
            'exclusions' => trim($_POST['exclusions'] ?? ''),
            'description_id' => trim($_POST['description_id'] ?? ''),
            'description_en' => trim($_POST['description_en'] ?? ''),
        ];
        $model->update($id, $data);
        // image upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['image'];
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $allowed = ['jpg','jpeg','png','webp'];
            if (in_array(strtolower($ext), $allowed, true)) {
                $dir = __DIR__ . '/../../../uploads/packages';
                if (!is_dir($dir)) {
                    mkdir($dir, 0777, true);
                }
                $filename = $id . '_' . time() . '.' . $ext;
                $target = $dir . '/' . $filename;
                move_uploaded_file($file['tmp_name'], $target);
                $imgModel = new PackageImageModel();
                $imgModel->create([
                    'package_id' => $id,
                    'path' => 'uploads/packages/' . $filename,
                ]);
            }
        }
        $this->redirect('/admin/packages');
    }

    public function delete(int $id): void
    {
        require_role('admin');
        $model = new PackageModel();
        $model->delete($id);
        $this->redirect('/admin/packages');
    }
}
