<?php
namespace App\Controllers\Admin;

use Controller;
use App\Models\BookingModel;
use App\Models\VillaModel;
use App\Models\PackageModel;

/**
 * Admin\BookingsController
 *
 * Provides an interface for administrators to view all bookings and
 * inspect individual booking details. Does not permit editing or
 * deleting bookings directly to preserve data integrity.
 */
class BookingsController extends Controller
{
    public function index(): void
    {
        require_role('admin');
        $model = new BookingModel();
        $sql = "SELECT * FROM bookings ORDER BY created_at DESC";
        $stmt = $model->query($sql);
        $bookings = $stmt->fetchAll();
        // Attach product names
        $villaModel = new VillaModel();
        $packageModel = new PackageModel();
        foreach ($bookings as &$bk) {
            if ($bk['type'] === 'villa') {
                $v = $villaModel->find($bk['reference_id']);
                $bk['product_name'] = $v['name_en'] ?? 'Villa';
            } else {
                $p = $packageModel->find($bk['reference_id']);
                $bk['product_name'] = $p['name_en'] ?? 'Package';
            }
        }
        $this->render('admin/bookings_list', [
            'bookings' => $bookings,
        ], 'admin');
    }

    /**
     * View details of a single booking.
     *
     * @param int $id
     */
    public function view(int $id): void
    {
        require_role('admin');
        $model = new BookingModel();
        $booking = $model->find($id);
        if (!$booking) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Booking not found.</p>';
            return;
        }
        // Load product
        if ($booking['type'] === 'villa') {
            $product = (new VillaModel())->find($booking['reference_id']);
        } else {
            $product = (new PackageModel())->find($booking['reference_id']);
        }
        $this->render('admin/booking_detail', [
            'booking' => $booking,
            'product' => $product,
        ], 'admin');
    }
}