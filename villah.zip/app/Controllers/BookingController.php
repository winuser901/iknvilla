<?php
namespace App\Controllers;

use Controller;
use App\Models\VillaModel;
use App\Models\PackageModel;
use App\Models\BookingModel;
use App\Models\PaymentModel;
use App\Models\PromoCodeModel;

/**
 * BookingController
 *
 * Manages the booking process from presenting the booking form,
 * creating bookings with applied discounts and generating the invoice
 * pages. It also handles uploading payment proofs for bank transfers.
 */
class BookingController extends Controller
{
    /**
     * Display the booking form for a villa or package. Requires the
     * customer to be logged in. Populates the form with product
     * details and pricing information.
     *
     * @param string $type 'villa' or 'package'
     * @param int    $id   ID of the villa or package
     */
    public function form(string $type, int $id): void
    {
        require_login('/login');
        if ($type === 'villa') {
            $productModel = new VillaModel();
        } else {
            $productModel = new PackageModel();
        }
        $product = $productModel->find($id);
        if (!$product) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Item not found.</p>';
            return;
        }
        $this->render('booking/form', [
            'type'      => $type,
            'product'   => $product,
        ]);
    }

    /**
     * Handle submission of the booking form. Validates input and
     * creates a booking via the BookingModel. On success redirects
     * to the invoice page. On failure redisplays the form with errors.
     *
     * @param string $type
     * @param int    $id
     */
    public function create(string $type, int $id): void
    {
        require_login('/login');
        // Read user input
        $startDate = $_POST['start_date'] ?? null;
        $endDate   = $_POST['end_date'] ?? null;
        $guests    = (int)($_POST['guests'] ?? 1);
        $participants = (int)($_POST['participants'] ?? 1);
        $paymentOption = $_POST['payment_option'] ?? 'FULL';
        $promoCode = trim($_POST['promo_code'] ?? '');
        $errors = [];
        if (!$startDate) {
            $errors[] = $this->t('Start date is required');
        }
        if ($type === 'villa' && !$endDate) {
            $errors[] = $this->t('End date is required');
        }
        if ($type === 'villa' && strtotime($endDate) <= strtotime($startDate)) {
            $errors[] = $this->t('Check‑out date must be after check‑in date');
        }
        if ($type === 'package') {
            // For packages participants must be within allowed range; we skip for brevity
        }
        if ($errors) {
            // Re-render form with errors
            if ($type === 'villa') {
                $productModel = new VillaModel();
            } else {
                $productModel = new PackageModel();
            }
            $product = $productModel->find($id);
            $this->render('booking/form', [
                'type'    => $type,
                'product' => $product,
                'errors'  => $errors,
            ]);
            return;
        }
        $bookingModel = new BookingModel();
        $userId = $_SESSION['user_id'];
        // Determine number of participants/guests
        $count = ($type === 'villa') ? max(1, $guests) : max(1, $participants);
        $booking = $bookingModel->createBooking(
            $userId,
            $type,
            $id,
            $startDate,
            $type === 'villa' ? $endDate : null,
            $count,
            $paymentOption,
            $promoCode ?: null
        );
        if (!$booking) {
            $errors[] = $this->t('Unable to create booking. Please try again.');
            // Rerender form
            if ($type === 'villa') {
                $productModel = new VillaModel();
            } else {
                $productModel = new PackageModel();
            }
            $product = $productModel->find($id);
            $this->render('booking/form', [
                'type'    => $type,
                'product' => $product,
                'errors'  => $errors,
            ]);
            return;
        }
        $this->redirect('/booking/' . $booking['booking_code']);
    }

    /**
     * Display an invoice page for a booking, summarizing pricing and
     * payment instructions. Only the booking owner or an admin may
     * view the invoice. If the booking is not found or access is
     * denied, a 404 is returned.
     *
     * @param string $code Booking code
     */
    public function invoice(string $code): void
    {
        require_login('/login');
        // Fetch booking by code
        $sql = "SELECT * FROM bookings WHERE booking_code = :code LIMIT 1";
        $stmt = (new BookingModel())->query($sql, ['code' => $code]);
        $booking = $stmt->fetch();
        if (!$booking) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Booking not found.</p>';
            return;
        }
        // Authorize user
        $user = current_user();
        if (!$user || ($user['role'] !== 'admin' && $booking['user_id'] != $user['id'])) {
            http_response_code(403);
            echo '<h1>403 Forbidden</h1><p>You are not allowed to view this booking.</p>';
            return;
        }
        // Determine the product for display
        if ($booking['type'] === 'villa') {
            $product = (new VillaModel())->find($booking['reference_id']);
        } else {
            $product = (new PackageModel())->find($booking['reference_id']);
        }
        // Payment instruction (retrieve from settings or hardcoded)
        $bankAccount = '1234567890 (BCA)';
        $qrisImage   = base_url('assets/images/qris.png'); // placeholder QR code image

        // Determine if a payment proof has been uploaded and is pending verification
        $pendingProof = false;
        try {
            $db = (new PaymentModel())->query(
                "SELECT COUNT(*) AS cnt FROM payments WHERE booking_id = :bid AND verification_status = 'PENDING'",
                ['bid' => $booking['id']]
            );
            $row = $db->fetch();
            $pendingProof = $row && $row['cnt'] > 0;
        } catch (\Throwable $e) {
            // ignore errors; treat as no pending proof
            $pendingProof = false;
        }
        $this->render('booking/invoice', [
            'booking'      => $booking,
            'product'      => $product,
            'bankAccount'  => $bankAccount,
            'qrisImage'    => $qrisImage,
            'pendingProof' => $pendingProof,
        ]);
    }

    /**
     * Show form to upload proof of payment for a given booking. The
     * amount due is derived from booking amounts. Only allows upload
     * when payment is pending or partial.
     *
     * @param string $code
     */
    public function uploadProofForm(string $code): void
    {
        require_login('/login');
        $booking = $this->fetchBookingByCode($code);
        if (!$booking) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Booking not found.</p>';
            return;
        }
        // Only owner may upload
        $user = current_user();
        if ($booking['user_id'] != $user['id']) {
            http_response_code(403);
            echo '<h1>403 Forbidden</h1><p>Not your booking.</p>';
            return;
        }
        // Determine amount due
        $amountDue = 0.0;
        $step = 1;
        if ($booking['payment_status'] === 'UNPAID') {
            $amountDue = $booking['amount_paid_now'];
            $step = 1;
        } elseif ($booking['payment_status'] === 'PARTIAL') {
            $amountDue = $booking['amount_remaining'];
            $step = 2;
        } else {
            // Already paid
            $amountDue = 0.0;
        }
        $this->render('booking/upload_proof', [
            'booking'   => $booking,
            'amountDue' => $amountDue,
            'step'      => $step,
        ]);
    }

    /**
     * Handle proof of payment upload. Saves the uploaded file to
     * uploads/proofs and records the payment. Only accepts JPG/PNG
     * images under 2MB. If successful redirects back to the invoice.
     *
     * @param string $code
     */
    public function uploadProof(string $code): void
    {
        require_login('/login');
        $booking = $this->fetchBookingByCode($code);
        if (!$booking) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Booking not found.</p>';
            return;
        }
        $user = current_user();
        if ($booking['user_id'] != $user['id']) {
            http_response_code(403);
            echo '<h1>403 Forbidden</h1><p>Not your booking.</p>';
            return;
        }
        // Determine payment step and amount
        $amount = 0.0;
        $step = 1;
        if ($booking['payment_status'] === 'UNPAID') {
            $amount = $booking['amount_paid_now'];
            $step = 1;
        } elseif ($booking['payment_status'] === 'PARTIAL') {
            $amount = $booking['amount_remaining'];
            $step = 2;
        } else {
            $this->redirect('/booking/' . $code);
            return;
        }
        // Validate uploaded file
        if (!isset($_FILES['proof']) || $_FILES['proof']['error'] !== UPLOAD_ERR_OK) {
            $errors = [$this->t('Please upload a valid proof of payment')];
            $this->render('booking/upload_proof', [
                'booking'   => $booking,
                'amountDue' => $amount,
                'step'      => $step,
                'errors'    => $errors,
            ]);
            return;
        }
        $file = $_FILES['proof'];
        $allowed = ['image/jpeg', 'image/png', 'image/webp'];
        if (!in_array($file['type'], $allowed, true) || $file['size'] > 2 * 1024 * 1024) {
            $errors = [$this->t('Invalid file type or size (max 2MB)')];
            $this->render('booking/upload_proof', [
                'booking'   => $booking,
                'amountDue' => $amount,
                'step'      => $step,
                'errors'    => $errors,
            ]);
            return;
        }
        // Save file
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $dir = __DIR__ . '/../../uploads/proofs';
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
        $filename = $code . '_step' . $step . '_' . time() . '.' . $ext;
        $target = $dir . '/' . $filename;
        move_uploaded_file($file['tmp_name'], $target);
        // Record payment
        $paymentModel = new PaymentModel();
        $paymentId = $paymentModel->createPayment((int)$booking['id'], $step, 'bank_transfer', $amount, 'proofs/' . $filename);
        // Redirect back to invoice
        $this->redirect('/booking/' . $code);
    }

    /**
     * Fetch a booking by code.
     *
     * @param string $code
     *
     * @return array|null
     */
    private function fetchBookingByCode(string $code): ?array
    {
        $model = new BookingModel();
        $sql = "SELECT * FROM bookings WHERE booking_code = :code LIMIT 1";
        $stmt = $model->query($sql, ['code' => $code]);
        $booking = $stmt->fetch();
        return $booking ?: null;
    }
}