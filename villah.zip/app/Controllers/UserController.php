<?php
namespace App\Controllers;

use Controller;
use App\Models\BookingModel;
use App\Models\VillaModel;
use App\Models\PackageModel;
use App\Models\UserModel;

/**
 * UserController
 *
 * Customer dashboard and profile management. Requires the user to
 * be logged in for all methods.
 */
class UserController extends Controller
{
    public function dashboard(): void
    {
        require_login('/login');
        $user = current_user();
        // Fetch user bookings
        $model = new BookingModel();
        $sql = "SELECT * FROM bookings WHERE user_id = :uid ORDER BY created_at DESC";
        $stmt = $model->query($sql, ['uid' => $user['id']]);
        $bookings = $stmt->fetchAll();
        // Attach product names
        $villaModel = new VillaModel();
        $packageModel = new PackageModel();
        foreach ($bookings as &$bk) {
            if ($bk['type'] === 'villa') {
                $v = $villaModel->find($bk['reference_id']);
                $bk['product_name'] = $v['name_' . ($_SESSION['lang'] ?? $this->config['default_language'])] ?? 'Villa';
            } else {
                $p = $packageModel->find($bk['reference_id']);
                $bk['product_name'] = $p['name_' . ($_SESSION['lang'] ?? $this->config['default_language'])] ?? 'Package';
            }
        }
        $this->render('user/dashboard', [
            'bookings' => $bookings,
        ]);
    }

    public function profileForm(): void
    {
        require_login('/login');
        $user = current_user();
        $this->render('user/profile', ['user' => $user]);
    }

    public function profileUpdate(): void
    {
        require_login('/login');
        $user = current_user();
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $preferredLanguage = $_POST['preferred_language'] ?? $user['preferred_language'];
        $errors = [];
        if (!$name || !$phone) {
            $errors[] = $this->t('Name and phone are required');
        }
        if (!in_array($preferredLanguage, $this->config['supported_languages'], true)) {
            $preferredLanguage = $this->config['default_language'];
        }
        if ($errors) {
            $this->render('user/profile', ['user' => $user, 'errors' => $errors]);
            return;
        }
        $model = new UserModel();
        $model->update($user['id'], [
            'name' => $name,
            'phone' => $phone,
            'preferred_language' => $preferredLanguage,
        ]);
        $_SESSION['lang'] = $preferredLanguage;
        $this->redirect('/profile');
    }
}