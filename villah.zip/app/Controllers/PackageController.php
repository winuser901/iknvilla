<?php
namespace App\Controllers;

use Controller;
use App\Models\PackageModel;
use App\Models\PackageImageModel;

/**
 * PackageController
 *
 * Lists holiday packages and shows detailed pages for individual
 * packages. Query parameters allow simple filtering by city and
 * keyword.
 */
class PackageController extends Controller
{
    public function index(): void
    {
        $model = new PackageModel();
        $city = $_GET['city'] ?? null;
        $keyword = $_GET['q'] ?? null;
        // For now, reuse search logic from VillaModel by simply ignoring keyword filtering.
        $packages = $model->getActive();
        $this->render('packages/index', [
            'packages' => $packages,
            'city'     => $city,
            'keyword'  => $keyword,
        ]);
    }

    public function detail(string $slug): void
    {
        $model = new PackageModel();
        $package = $model->getBySlug($slug);
        if (!$package) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Package not found.</p>';
            return;
        }
        $imageModel = new PackageImageModel();
        $images = $imageModel->getByPackage($package['id']);
        $this->render('packages/detail', [
            'package' => $package,
            'images'  => $images,
        ]);
    }
}