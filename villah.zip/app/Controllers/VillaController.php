<?php
namespace App\Controllers;

use Controller;
use App\Models\VillaModel;
use App\Models\VillaImageModel;

/**
 * VillaController
 *
 * Handles public listing and detail pages for villas. Includes simple
 * search filters via query parameters. Each villa has a detail page
 * showing its description and photo gallery.
 */
class VillaController extends Controller
{
    /**
     * List active villas. Supports optional query parameters for city
     * (e.g. ?city=Bali) and keyword search (e.g. ?q=luxury). Results
     * are ordered by creation date descending.
     */
    public function index(): void
    {
        $model = new VillaModel();
        $city = $_GET['city'] ?? null;
        $keyword = $_GET['q'] ?? null;
        $villas = $model->search($city, $keyword);
        $this->render('villas/index', [
            'villas' => $villas,
            'city'   => $city,
            'keyword'=> $keyword,
        ]);
    }

    /**
     * Show the details of a single villa identified by its slug. If the
     * villa cannot be found a 404 error page is displayed. Image data
     * is loaded via VillaImageModel.
     *
     * @param string $slug
     */
    public function detail(string $slug): void
    {
        $model = new VillaModel();
        $villa = $model->getBySlug($slug);
        if (!$villa) {
            http_response_code(404);
            echo '<h1>404 Not Found</h1><p>Villa not found.</p>';
            return;
        }
        $imageModel = new VillaImageModel();
        $images = $imageModel->getByVilla($villa['id']);
        $this->render('villas/detail', [
            'villa'  => $villa,
            'images' => $images,
        ]);
    }
}