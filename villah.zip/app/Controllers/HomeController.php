<?php
namespace App\Controllers;

use Controller;
use App\Models\VillaModel;
use App\Models\PackageModel;

/**
 * HomeController
 *
 * Handles the landing page and language switching. The index page
 * displays a selection of popular villas and packages along with
 * promotional banners. Language switching is implemented by storing
 * the selected locale in the session and reloading the previous page.
 */
class HomeController extends Controller
{
    /**
     * Show landing page with popular villas and packages.
     */
    public function index(): void
    {
        $villaModel = new VillaModel();
        $packageModel = new PackageModel();
        $villas = $villaModel->getPopular(3);
        $packages = $packageModel->getPopular(3);
        $this->render('home/index', [
            'villas'   => $villas,
            'packages' => $packages,
        ]);
    }

    /**
     * Switch UI language. Accepts a two‑letter locale code. The selected
     * locale must be in the supported_languages list. After updating
     * the session the user is redirected back to the referring page if
     * available, or to the home page otherwise.
     *
     * @param string $locale
     */
    public function switchLang(string $locale): void
    {
        $supported = $this->config['supported_languages'];
        if (in_array($locale, $supported, true)) {
            $_SESSION['lang'] = $locale;
        }
        $ref = $_SERVER['HTTP_REFERER'] ?? $this->baseUrl();
        $this->redirect($ref);
    }
}