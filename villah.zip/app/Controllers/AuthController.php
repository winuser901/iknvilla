<?php
namespace App\Controllers;

use Controller;
use App\Models\UserModel;

/**
 * AuthController
 *
 * Handles login, registration and logout for customers. Admin users
 * authenticate via a separate controller under the Admin namespace.
 */
class AuthController extends Controller
{
    public function loginForm(): void
    {
        // If already logged in, redirect to dashboard
        if (isset($_SESSION['user_id'])) {
            $this->redirect('/dashboard');
        }
        $this->render('auth/login');
    }

    public function login(): void
    {
        $email    = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $errors   = [];
        if (!$email || !$password) {
            $errors[] = $this->t('Please enter email and password');
        } else {
            $model = new UserModel();
            $user  = $model->findByEmail($email);
            if (!$user || !password_verify($password, $user['password_hash'])) {
                $errors[] = $this->t('Invalid email or password');
            } else {
                // Successful login
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role']    = $user['role'];
                $_SESSION['lang']    = $user['preferred_language'] ?? $this->config['default_language'];
                $this->redirect('/dashboard');
                return;
            }
        }
        // Render form with error
        $this->render('auth/login', ['errors' => $errors, 'email' => $email]);
    }

    public function registerForm(): void
    {
        if (isset($_SESSION['user_id'])) {
            $this->redirect('/dashboard');
        }
        $this->render('auth/register');
    }

    public function register(): void
    {
        $name     = trim($_POST['name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $phone    = trim($_POST['phone'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $confirm  = trim($_POST['confirm_password'] ?? '');
        $errors   = [];
        if (!$name || !$email || !$phone || !$password || !$confirm) {
            $errors[] = $this->t('All fields are required');
        }
        if ($password !== $confirm) {
            $errors[] = $this->t('Passwords do not match');
        }
        $model = new UserModel();
        if ($model->findByEmail($email)) {
            $errors[] = $this->t('Email already registered');
        }
        if ($errors) {
            $this->render('auth/register', ['errors' => $errors, 'name' => $name, 'email' => $email, 'phone' => $phone]);
            return;
        }
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $userId = $model->create([
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'password_hash' => $hash,
            'role' => 'customer',
            'preferred_language' => $this->config['default_language'],
        ]);
        // auto login
        $_SESSION['user_id'] = $userId;
        $_SESSION['role']    = 'customer';
        $_SESSION['lang']    = $this->config['default_language'];
        $this->redirect('/dashboard');
    }

    public function logout(): void
    {
        session_destroy();
        $this->redirect('/');
    }
}