<?php
// Booking form view. Displays the product (villa or package) details and
// collects the necessary booking information from the user.
?>

<h1><?php echo $t('Book'); ?> <?php echo htmlspecialchars($product['name_' . ($_SESSION['lang'] ?? 'id')]); ?></h1>

<?php if (!empty($errors)): ?>
    <div class="alert">
        <?php foreach ($errors as $err): ?>
            <p><?php echo htmlspecialchars($err); ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Product summary card -->
<div class="booking-product-summary card">
    <?php
    // Determine a placeholder image; in real app, use first associated image
    $img = 'assets/images/villa1.png';
    if ($type !== 'villa') {
        $img = 'assets/images/villa2.png';
    }
    ?>
    <img src="<?php echo base_url($img); ?>" alt="<?php echo htmlspecialchars($product['name_' . ($_SESSION['lang'] ?? 'id')]); ?>" style="width:100%; height:180px; object-fit:cover;">
    <div class="card-body">
        <h2 class="card-title" style="margin-top:0;"><?php echo htmlspecialchars($product['name_' . ($_SESSION['lang'] ?? 'id')]); ?></h2>
        <?php if ($type === 'villa'): ?>
            <p class="card-text"><?php echo $t('Price per night'); ?>: Rp<?php echo number_format($product['base_price_per_night'], 0, ',', '.'); ?></p>
        <?php else: ?>
            <p class="card-text"><?php echo $t('Price per person'); ?>: Rp<?php echo number_format($product['base_price_per_person'], 0, ',', '.'); ?></p>
            <p class="card-text"><?php echo $t('Duration'); ?>: <?php echo (int)$product['duration_days']; ?> <?php echo $t('Days'); ?></p>
        <?php endif; ?>
    </div>
</div>

<form method="POST" action="<?php echo base_url('booking/' . $type . '/' . $product['id']); ?>">
    <input type="hidden" id="price_unit" value="<?php echo $type === 'villa' ? (float)$product['base_price_per_night'] : (float)$product['base_price_per_person']; ?>">
    <input type="hidden" id="type" value="<?php echo htmlspecialchars($type); ?>">

    <label for="start_date"><?php echo $t('Start Date'); ?></label>
    <input type="date" name="start_date" id="start_date" required>

    <?php if ($type === 'villa'): ?>
        <label for="end_date"><?php echo $t('End Date'); ?></label>
        <input type="date" name="end_date" id="end_date" required>
        <label for="guests"><?php echo $t('Number of Guests'); ?></label>
        <input type="number" name="guests" id="guests" min="1" max="<?php echo (int)$product['max_guest']; ?>" value="1">
    <?php else: ?>
        <label for="participants"><?php echo $t('Number of Participants'); ?></label>
        <input type="number" name="participants" id="participants" min="<?php echo (int)$product['min_people']; ?>" max="<?php echo (int)$product['max_people']; ?>" value="<?php echo (int)$product['min_people']; ?>">
    <?php endif; ?>

    <label for="promo_code"><?php echo $t('Promo Code'); ?></label>
    <input type="text" name="promo_code" id="promo_code" placeholder="">

    <label for="payment_option"><?php echo $t('Select Payment Option'); ?></label>
    <select name="payment_option" id="payment_option" onchange="updateSummary()">
        <option value="FULL"><?php echo $t('Full Payment'); ?></option>
        <option value="DP75"><?php echo $t('Down Payment 75%'); ?></option>
        <option value="DP50"><?php echo $t('Down Payment 50%'); ?></option>
    </select>

    <!-- Booking summary displayed when dates are selected -->
    <div id="booking-summary" style="display:none; margin-top:20px; padding:15px; border:1px solid #e6eaf0; border-radius:4px; background:#f8fafc;">
        <h3 style="margin-top:0;"><?php echo $t('Booking Summary'); ?></h3>
        <p><strong><?php echo $t('Start'); ?>:</strong> <span id="summary-start"></span></p>
        <?php if ($type === 'villa'): ?>
        <p><strong><?php echo $t('End'); ?>:</strong> <span id="summary-end"></span></p>
        <p><strong><?php echo $t('Total Nights'); ?>:</strong> <span id="summary-nights"></span></p>
        <?php else: ?>
        <p><strong><?php echo $t('Participants'); ?>:</strong> <span id="summary-count"></span></p>
        <?php endif; ?>
        <p><strong><?php echo $t('Subtotal'); ?>:</strong> Rp<span id="summary-subtotal"></span></p>
        <p><strong><?php echo $t('Payment option'); ?>:</strong> <span id="summary-payment-option"></span></p>
        <p><strong><?php echo $t('Pay Now'); ?>:</strong> Rp<span id="summary-paynow"></span></p>
        <p style="font-size:0.9em; color:#555;"><?php echo $t('Discount will be applied on invoice.'); ?></p>
    </div>

    <button type="submit"><?php echo $t('Submit Booking'); ?></button>
</form>

<script>
// Helper to format number to Indonesian Rupiah
function formatRupiah(num) {
    return (num).toLocaleString('id-ID');
}
function calculateSummary() {
    var type = document.getElementById('type').value;
    var price = parseFloat(document.getElementById('price_unit').value || 0);
    var start = document.getElementById('start_date').value;
    var end = document.getElementById('end_date') ? document.getElementById('end_date').value : '';
    var guests = document.getElementById('guests');
    var participants = document.getElementById('participants');
    var count = 1;
    if (type === 'villa') {
        count = guests && guests.value ? parseInt(guests.value) : 1;
    } else {
        count = participants && participants.value ? parseInt(participants.value) : 1;
    }
    var nights = 1;
    if (type === 'villa') {
        if (start && end) {
            var d1 = new Date(start);
            var d2 = new Date(end);
            var diff = Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
            nights = diff > 0 ? diff : 1;
        }
    }
    var subtotal;
    if (type === 'villa') {
        subtotal = nights * price;
    } else {
        subtotal = count * price;
    }
    var paymentOption = document.getElementById('payment_option').value;
    var payNow = subtotal;
    if (paymentOption === 'DP75') {
        payNow = subtotal * 0.75;
    } else if (paymentOption === 'DP50') {
        payNow = subtotal * 0.50;
    }
    // Update DOM
    document.getElementById('summary-start').textContent = start;
    if (document.getElementById('summary-end')) {
        document.getElementById('summary-end').textContent = end;
    }
    if (document.getElementById('summary-nights')) {
        document.getElementById('summary-nights').textContent = nights;
    }
    if (document.getElementById('summary-count')) {
        document.getElementById('summary-count').textContent = count;
    }
    document.getElementById('summary-subtotal').textContent = formatRupiah(subtotal);
    var paymentText = '';
    if (paymentOption === 'FULL') paymentText = '<?php echo $t('Full Payment'); ?>';
    else if (paymentOption === 'DP75') paymentText = '<?php echo $t('Down Payment 75%'); ?>';
    else if (paymentOption === 'DP50') paymentText = '<?php echo $t('Down Payment 50%'); ?>';
    document.getElementById('summary-payment-option').textContent = paymentText;
    document.getElementById('summary-paynow').textContent = formatRupiah(payNow);
    // Show summary if start date selected (and end date for villa)
    var summary = document.getElementById('booking-summary');
    if (type === 'villa') {
        summary.style.display = (start && end) ? 'block' : 'none';
    } else {
        summary.style.display = start ? 'block' : 'none';
    }
}
function updateSummary() {
    calculateSummary();
}
// Attach event listeners
document.addEventListener('DOMContentLoaded', function() {
    var inputs = ['start_date', 'end_date', 'guests', 'participants', 'payment_option'];
    inputs.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) {
            el.addEventListener('change', calculateSummary);
        }
    });
});
</script>