<?php
// Invoice page for a booking. Shows summary and payment instructions.
?>
<h1><?php echo $t('Booking Summary'); ?></h1>

<table>
    <tr>
        <th><?php echo $t('Booking Code'); ?></th>
        <td><?php echo htmlspecialchars($booking['booking_code']); ?></td>
    </tr>
    <tr>
        <th><?php echo $t('Product Name'); ?></th>
        <td><?php echo htmlspecialchars($product['name_' . ($_SESSION['lang'] ?? 'id')]); ?></td>
    </tr>
    <tr>
        <th><?php echo $t('Type'); ?></th>
        <td><?php echo htmlspecialchars(ucfirst($booking['type'])); ?></td>
    </tr>
    <tr>
        <th><?php echo $t('Start'); ?></th>
        <td><?php echo htmlspecialchars($booking['start_date']); ?></td>
    </tr>
    <?php if ($booking['type'] === 'villa'): ?>
    <tr>
        <th><?php echo $t('End'); ?></th>
        <td><?php echo htmlspecialchars($booking['end_date']); ?></td>
    </tr>
    <?php endif; ?>
    <tr>
        <th><?php echo $t('Subtotal'); ?></th>
        <td>Rp<?php echo number_format($booking['subtotal'], 0, ',', '.'); ?></td>
    </tr>
    <tr>
        <th><?php echo $t('Discount'); ?></th>
        <td>Rp<?php echo number_format($booking['discount_amount'], 0, ',', '.'); ?></td>
    </tr>
    <tr>
        <th><?php echo $t('Grand Total'); ?></th>
        <td>Rp<?php echo number_format($booking['grand_total'], 0, ',', '.'); ?></td>
    </tr>
    <tr>
        <th><?php echo $t('Amount Paid'); ?></th>
        <td>Rp<?php echo number_format($booking['amount_paid_now'], 0, ',', '.'); ?></td>
    </tr>
    <tr>
        <th><?php echo $t('Amount Remaining'); ?></th>
        <td>Rp<?php echo number_format($booking['amount_remaining'], 0, ',', '.'); ?></td>
    </tr>
    <?php if ($booking['amount_remaining'] > 0): ?>
    <tr>
        <th><?php echo $t('Due Date'); ?></th>
        <td><?php echo htmlspecialchars($booking['due_date_remaining']); ?></td>
    </tr>
    <?php endif; ?>
    <tr>
        <th><?php echo $t('Payment Status'); ?></th>
        <td><?php echo htmlspecialchars($booking['payment_status']); ?></td>
    </tr>
    <tr>
        <th><?php echo $t('Booking Status'); ?></th>
        <td><?php echo htmlspecialchars($booking['booking_status']); ?></td>
    </tr>
</table>

<h2><?php echo $t('Payment Due'); ?></h2>
<?php
    $dueAmount = 0.0;
    $stepLabel = '';
    if ($booking['payment_status'] === 'UNPAID') {
        $dueAmount = $booking['amount_paid_now'];
        $stepLabel = $t('First Payment');
    } elseif ($booking['payment_status'] === 'PARTIAL') {
        $dueAmount = $booking['amount_remaining'];
        $stepLabel = $t('Second Payment');
    }
?>

<?php if ($dueAmount > 0): ?>
    <p><strong><?php echo htmlspecialchars($stepLabel); ?>:</strong> Rp<?php echo number_format($dueAmount, 0, ',', '.'); ?></p>
    <p><?php echo $t('Please transfer to the following bank account'); ?>:</p>
    <p><?php echo htmlspecialchars($bankAccount); ?></p>
    <?php if ($qrisImage): ?>
        <p><?php echo $t('Or scan QRIS'); ?>:</p>
        <img src="<?php echo $qrisImage; ?>" alt="QRIS" style="width: 200px;">
    <?php endif; ?>
    <a class="btn" href="<?php echo base_url('booking/' . $booking['booking_code'] . '/upload-proof'); ?>">
        <?php echo $t('Upload Proof'); ?>
    </a>

    <?php if (!empty($pendingProof)): ?>
        <div class="alert" style="margin-top:15px;">
            <?php echo $t('Proof uploaded. Waiting for admin verification.'); ?>
        </div>
    <?php endif; ?>
<?php else: ?>
    <p><?php echo $t('Thank you. Your payment is complete.'); ?></p>
<?php endif; ?>

<a class="btn" href="<?php echo base_url('dashboard'); ?>"><?php echo $t('Back'); ?></a>