<?php
// Upload proof of payment page. Users can upload payment receipts
// corresponding to the due amount.
?>
<h1><?php echo $t('Upload Payment Proof'); ?></h1>

<p>
    <?php echo $t('Booking Code'); ?>: <?php echo htmlspecialchars($booking['booking_code']); ?>
    <br>
    <?php echo $t('Amount'); ?>: Rp<?php echo number_format($amountDue, 0, ',', '.'); ?>
    <br>
    <?php echo $t('Payment Step'); ?>: <?php echo ($step === 1) ? $t('First Payment') : $t('Second Payment'); ?>
</p>

<?php if (!empty($errors)): ?>
    <div class="alert">
        <?php foreach ($errors as $error): ?>
            <p><?php echo htmlspecialchars($error); ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo base_url('booking/' . $booking['booking_code'] . '/upload-proof'); ?>" enctype="multipart/form-data">
    <label for="proof"><?php echo $t('Proof'); ?></label>
    <input type="file" name="proof" id="proof" accept="image/jpeg,image/png,image/webp" required>
    <button type="submit"><?php echo $t('Upload'); ?></button>
</form>

<a class="btn" href="<?php echo base_url('booking/' . $booking['booking_code']); ?>"><?php echo $t('Back'); ?></a>