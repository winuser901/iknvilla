<?php
// Packages listing page
?>
<h1><?php echo $t('Packages'); ?></h1>

<?php if (!empty($packages)): ?>
    <div class="grid">
        <?php foreach ($packages as $p): ?>
            <div class="card" style="width: 30%; min-width: 250px;">
                <?php $imgPath = 'assets/images/villa2.png'; ?>
                <img src="<?php echo base_url($imgPath); ?>" alt="<?php echo htmlspecialchars($p['name_en']); ?>">
                <div class="card-body">
                    <h3 class="card-title">
                        <a href="<?php echo base_url('packages/' . $p['slug']); ?>">
                            <?php echo htmlspecialchars($p['name_' . ($_SESSION['lang'] ?? 'id')]); ?>
                        </a>
                    </h3>
                    <p class="card-text">
                        <?php echo $t('Price from'); ?> Rp<?php echo number_format($p['base_price_per_person'], 0, ',', '.'); ?>/<?php echo $t('person') ?? 'orang'; ?>
                    </p>
                    <a class="btn" href="<?php echo base_url('booking/package/' . $p['id']); ?>">
                        <?php echo $t('Book Now'); ?>
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <p><?php echo $t('No packages found'); ?></p>
<?php endif; ?>

<style>
@media (max-width: 600px) {
    .card {
        width: 100%;
    }
}
</style>