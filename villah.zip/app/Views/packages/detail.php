<?php
// Package detail page
?>
<h1><?php echo htmlspecialchars($package['name_' . ($_SESSION['lang'] ?? 'id')]); ?></h1>

<p><strong><?php echo $t('City'); ?>:</strong> <?php echo htmlspecialchars($package['city']); ?></p>
<p><strong><?php echo $t('Duration'); ?>:</strong> <?php echo (int)$package['duration_days']; ?> <?php echo $t('Days'); ?></p>
<p><strong><?php echo $t('Price per person'); ?>:</strong> Rp<?php echo number_format($package['base_price_per_person'], 0, ',', '.'); ?></p>

<?php if (!empty($images)): ?>
    <h3><?php echo $t('Image Gallery'); ?></h3>
    <div class="gallery">
        <?php foreach ($images as $img): ?>
            <img src="<?php echo base_url($img['path']); ?>" alt="<?php echo htmlspecialchars($package['name_en']); ?>" style="width: 100%; max-width: 300px; margin: 5px;">
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<h3><?php echo $t('Description'); ?></h3>
<p><?php echo nl2br(htmlspecialchars($package['description_' . ($_SESSION['lang'] ?? 'id')])); ?></p>

<?php if ($package['inclusions']): ?>
<h3><?php echo $t('Inclusions'); ?></h3>
<ul>
    <?php foreach (explode(',', $package['inclusions']) as $inc): ?>
        <li><?php echo htmlspecialchars(trim($inc)); ?></li>
    <?php endforeach; ?>
</ul>
<?php endif; ?>

<?php if ($package['exclusions']): ?>
<h3><?php echo $t('Exclusions'); ?></h3>
<ul>
    <?php foreach (explode(',', $package['exclusions']) as $exc): ?>
        <li><?php echo htmlspecialchars(trim($exc)); ?></li>
    <?php endforeach; ?>
</ul>
<?php endif; ?>

<a class="btn" href="<?php echo base_url('booking/package/' . $package['id']); ?>"><?php echo $t('Book Now'); ?></a>

<style>
.gallery {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}
.gallery img {
    border: 1px solid #ddd;
    border-radius: 4px;
    object-fit: cover;
}
</style>