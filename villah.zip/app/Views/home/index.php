<div class="hero" style="background-image: url('<?php echo base_url('assets/images/villa3.png'); ?>'); background-size: cover; background-position: center; padding: 80px 20px; color: #fff; text-align: center;">
    <h1 style="font-size: 2.5em; margin-bottom: 10px;">Bali Booking</h1>
    <p style="font-size: 1.1em; max-width: 600px; margin: 0 auto;">
        <?php echo $t('Find your perfect villa or holiday package in Bali'); ?>
    </p>
</div>

<section>
    <h2><?php echo $t('Villas'); ?></h2>
    <div class="grid">
        <?php foreach ($villas as $villa): ?>
            <div class="card">
                <?php
                    // Determine image path: use placeholder if no images
                    $imgPath = 'assets/images/villa1.png';
                    // In a real application fetch first image from villa_images table
                ?>
                <img src="<?php echo base_url($imgPath); ?>" alt="<?php echo htmlspecialchars($villa['name_en']); ?>">
                <div class="card-body">
                    <h3 class="card-title"><?php echo htmlspecialchars($villa['name_' . ($_SESSION['lang'] ?? 'id')]); ?></h3>
                    <p class="card-text">
                        <?php echo $t('Price from'); ?> Rp<?php echo number_format($villa['base_price_per_night'], 0, ',', '.'); ?>/malam
                    </p>
                    <a class="btn btn-primary" href="<?php echo base_url('villas/' . $villa['slug']); ?>"><?php echo $t('Book Now'); ?></a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<section>
    <h2><?php echo $t('Packages'); ?></h2>
    <div class="grid">
        <?php foreach ($packages as $package): ?>
            <div class="card">
                <?php $imgPath = 'assets/images/villa2.png'; ?>
                <img src="<?php echo base_url($imgPath); ?>" alt="<?php echo htmlspecialchars($package['name_en']); ?>">
                <div class="card-body">
                    <h3 class="card-title"><?php echo htmlspecialchars($package['name_' . ($_SESSION['lang'] ?? 'id')]); ?></h3>
                    <p class="card-text">
                        <?php echo $t('Price from'); ?> Rp<?php echo number_format($package['base_price_per_person'], 0, ',', '.'); ?>/orang
                    </p>
                    <a class="btn btn-primary" href="<?php echo base_url('packages/' . $package['slug']); ?>"><?php echo $t('Book Now'); ?></a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<style>
.grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}
.btn.btn-primary {
    display: inline-block;
    background-color: #0095da;
    color: #fff;
    padding: 8px 16px;
    border-radius: 4px;
    text-decoration: none;
    font-weight: 500;
}
.btn.btn-primary:hover {
    background-color: #007bbf;
}
</style>