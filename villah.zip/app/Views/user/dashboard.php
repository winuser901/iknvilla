<?php
// User dashboard page listing bookings
?>
<h1><?php echo $t('Your bookings'); ?></h1>

<?php if (!empty($bookings)): ?>
    <table>
        <thead>
            <tr>
                <th><?php echo $t('Booking Code'); ?></th>
                <th><?php echo $t('Product Name'); ?></th>
                <th><?php echo $t('Type'); ?></th>
                <th><?php echo $t('Start'); ?></th>
                <th><?php echo $t('End'); ?></th>
                <th><?php echo $t('Grand Total'); ?></th>
                <th><?php echo $t('Payment Status'); ?></th>
                <th><?php echo $t('Action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($bookings as $bk): ?>
                <tr>
                    <td><?php echo htmlspecialchars($bk['booking_code']); ?></td>
                    <td><?php echo htmlspecialchars($bk['product_name']); ?></td>
                    <td><?php echo htmlspecialchars(ucfirst($bk['type'])); ?></td>
                    <td><?php echo htmlspecialchars($bk['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($bk['type'] === 'villa' ? $bk['end_date'] : '-'); ?></td>
                    <td>Rp<?php echo number_format($bk['grand_total'], 0, ',', '.'); ?></td>
                    <td><?php echo htmlspecialchars($bk['payment_status']); ?></td>
                    <td><a href="<?php echo base_url('booking/' . $bk['booking_code']); ?>"><?php echo $t('View'); ?></a></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p><?php echo $t('No bookings yet.'); ?></p>
<?php endif; ?>

<a class="btn" href="<?php echo base_url('profile'); ?>"><?php echo $t('Update Profile'); ?></a>