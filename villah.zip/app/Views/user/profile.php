<?php
// User profile form page
?>
<h1><?php echo $t('Your profile'); ?></h1>

<?php if (!empty($errors)): ?>
    <div class="alert">
        <?php foreach ($errors as $error): ?>
            <p><?php echo htmlspecialchars($error); ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo base_url('profile'); ?>">
    <label for="name">Nama</label>
    <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
    <label for="phone">Telepon/WhatsApp</label>
    <input type="text" name="phone" id="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
    <label for="preferred_language"><?php echo $t('Preferred Language'); ?></label>
    <select name="preferred_language" id="preferred_language">
        <?php foreach ($this->config['supported_languages'] as $langCode): ?>
            <option value="<?php echo $langCode; ?>" <?php echo ($user['preferred_language'] === $langCode) ? 'selected' : ''; ?>><?php echo strtoupper($langCode); ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit"><?php echo $t('Save Changes'); ?></button>
</form>