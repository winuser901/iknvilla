<?php
// Customer login page
?>
<h1><?php echo $t('Login'); ?></h1>

<?php if (!empty($errors)): ?>
    <div class="alert">
        <?php foreach ($errors as $error): ?>
            <p><?php echo htmlspecialchars($error); ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo base_url('login'); ?>">
    <label for="email">Email</label>
    <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($email ?? ''); ?>" required>
    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>
    <button type="submit"><?php echo $t('Login'); ?></button>
</form>

<p>
    <?php echo $t('Don\'t have an account?'); ?>
    <a href="<?php echo base_url('register'); ?>"><?php echo $t('Register'); ?></a>
</p>