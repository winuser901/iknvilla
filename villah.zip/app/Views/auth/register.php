<?php
// Customer registration page
?>
<h1><?php echo $t('Register'); ?></h1>

<?php if (!empty($errors)): ?>
    <div class="alert">
        <?php foreach ($errors as $error): ?>
            <p><?php echo htmlspecialchars($error); ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo base_url('register'); ?>">
    <label for="name">Nama</label>
    <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($name ?? ''); ?>" required>
    <label for="email">Email</label>
    <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($email ?? ''); ?>" required>
    <label for="phone">Telepon/WhatsApp</label>
    <input type="text" name="phone" id="phone" value="<?php echo htmlspecialchars($phone ?? ''); ?>" required>
    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>
    <label for="confirm_password">Konfirmasi Password</label>
    <input type="password" name="confirm_password" id="confirm_password" required>
    <button type="submit"><?php echo $t('Register'); ?></button>
</form>

<p>
    <?php echo $t('Already have an account?'); ?>
    <a href="<?php echo base_url('login'); ?>"><?php echo $t('Login'); ?></a>
</p>