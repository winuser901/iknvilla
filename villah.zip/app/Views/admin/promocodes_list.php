<?php
// Admin listing of promo codes
?>
<h1>Promo Codes</h1>

<a class="btn" href="<?php echo base_url('admin/promo-codes/create'); ?>">+ Add Promo Code</a>

<?php if (!empty($promoCodes)): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Code</th>
                <th>Type</th>
                <th>Value</th>
                <th>Valid From</th>
                <th>Valid Until</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($promoCodes as $pc): ?>
                <tr>
                    <td><?php echo (int)$pc['id']; ?></td>
                    <td><?php echo htmlspecialchars($pc['code']); ?></td>
                    <td><?php echo htmlspecialchars($pc['discount_type']); ?></td>
                    <td><?php echo htmlspecialchars($pc['value']); ?></td>
                    <td><?php echo htmlspecialchars($pc['valid_from']); ?></td>
                    <td><?php echo htmlspecialchars($pc['valid_until']); ?></td>
                    <td><?php echo htmlspecialchars($pc['status']); ?></td>
                    <td>
                        <a href="<?php echo base_url('admin/promo-codes/edit/' . $pc['id']); ?>">Edit</a> |
                        <a href="<?php echo base_url('admin/promo-codes/delete/' . $pc['id']); ?>" onclick="return confirm('Delete this promo code?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No promo codes found.</p>
<?php endif; ?>