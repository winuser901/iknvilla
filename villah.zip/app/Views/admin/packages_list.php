<?php
// Admin listing of packages
?>
<h1><?php echo $t('Packages'); ?></h1>

<a class="btn" href="<?php echo base_url('admin/packages/create'); ?>">+ Add Package</a>

<?php if (!empty($packages)): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th><?php echo $t('Name'); ?></th>
                <th><?php echo $t('City'); ?></th>
                <th><?php echo $t('Price per person'); ?></th>
                <th><?php echo $t('Action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($packages as $p): ?>
                <tr>
                    <td><?php echo (int)$p['id']; ?></td>
                    <td><?php echo htmlspecialchars($p['name_en']); ?></td>
                    <td><?php echo htmlspecialchars($p['city']); ?></td>
                    <td>Rp<?php echo number_format($p['base_price_per_person'], 0, ',', '.'); ?></td>
                    <td>
                        <a href="<?php echo base_url('admin/packages/edit/' . $p['id']); ?>">Edit</a> |
                        <a href="<?php echo base_url('admin/packages/delete/' . $p['id']); ?>" onclick="return confirm('Delete this package?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p><?php echo $t('No packages found'); ?></p>
<?php endif; ?>