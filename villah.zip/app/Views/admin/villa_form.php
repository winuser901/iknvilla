<?php
// Admin villa create/edit form
?>
<h1><?php echo $villa ? 'Edit Villa' : 'Add Villa'; ?></h1>

<form method="POST" action="<?php echo base_url($villa ? 'admin/villas/edit/' . $villa['id'] : 'admin/villas/create'); ?>" enctype="multipart/form-data">
    <label for="name_id">Nama (ID)</label>
    <input type="text" name="name_id" id="name_id" value="<?php echo htmlspecialchars($villa['name_id'] ?? ''); ?>" required>
    <label for="name_en">Name (EN)</label>
    <input type="text" name="name_en" id="name_en" value="<?php echo htmlspecialchars($villa['name_en'] ?? ''); ?>" required>
    <label for="slug">Slug</label>
    <input type="text" name="slug" id="slug" value="<?php echo htmlspecialchars($villa['slug'] ?? ''); ?>">
    <label for="location">Location</label>
    <input type="text" name="location" id="location" value="<?php echo htmlspecialchars($villa['location'] ?? ''); ?>" required>
    <label for="city">City</label>
    <input type="text" name="city" id="city" value="<?php echo htmlspecialchars($villa['city'] ?? ''); ?>" required>
    <label for="country">Country</label>
    <input type="text" name="country" id="country" value="<?php echo htmlspecialchars($villa['country'] ?? 'Indonesia'); ?>">
    <label for="max_guest">Max Guest</label>
    <input type="number" name="max_guest" id="max_guest" value="<?php echo htmlspecialchars($villa['max_guest'] ?? '2'); ?>" min="1">
    <label for="base_price_per_night">Base Price Per Night</label>
    <input type="number" name="base_price_per_night" id="base_price_per_night" value="<?php echo htmlspecialchars($villa['base_price_per_night'] ?? ''); ?>" step="0.01" required>
    <label for="facilities">Facilities (comma separated)</label>
    <input type="text" name="facilities" id="facilities" value="<?php echo htmlspecialchars($villa['facilities'] ?? ''); ?>">
    <label for="tags">Tags (comma separated)</label>
    <input type="text" name="tags" id="tags" value="<?php echo htmlspecialchars($villa['tags'] ?? ''); ?>">
    <label for="description_id">Description (ID)</label>
    <textarea name="description_id" id="description_id" rows="4"><?php echo htmlspecialchars($villa['description_id'] ?? ''); ?></textarea>
    <label for="description_en">Description (EN)</label>
    <textarea name="description_en" id="description_en" rows="4"><?php echo htmlspecialchars($villa['description_en'] ?? ''); ?></textarea>
    <label for="image">Upload Image</label>
    <input type="file" name="image" id="image" accept="image/jpeg,image/png,image/webp">
    <button type="submit"><?php echo $villa ? 'Update' : 'Create'; ?></button>
</form>

<a class="btn" href="<?php echo base_url('admin/villas'); ?>"><?php echo $t('Back'); ?></a>