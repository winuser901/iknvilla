<?php
// Admin view of a specific booking
?>
<h1><?php echo $t('Booking Details'); ?></h1>

<table>
    <tr><th><?php echo $t('Booking Code'); ?></th><td><?php echo htmlspecialchars($booking['booking_code']); ?></td></tr>
    <tr><th><?php echo $t('User'); ?></th><td><?php echo htmlspecialchars($booking['user_id']); ?></td></tr>
    <tr><th><?php echo $t('Product Name'); ?></th><td><?php echo htmlspecialchars($product['name_en']); ?></td></tr>
    <tr><th><?php echo $t('Type'); ?></th><td><?php echo htmlspecialchars($booking['type']); ?></td></tr>
    <tr><th><?php echo $t('Start'); ?></th><td><?php echo htmlspecialchars($booking['start_date']); ?></td></tr>
    <?php if ($booking['type'] === 'villa'): ?>
    <tr><th><?php echo $t('End'); ?></th><td><?php echo htmlspecialchars($booking['end_date']); ?></td></tr>
    <?php endif; ?>
    <tr><th><?php echo $t('Participants'); ?></th><td><?php echo (int)$booking['participants']; ?></td></tr>
    <tr><th><?php echo $t('Grand Total'); ?></th><td>Rp<?php echo number_format($booking['grand_total'], 0, ',', '.'); ?></td></tr>
    <tr><th><?php echo $t('Amount Paid'); ?></th><td>Rp<?php echo number_format($booking['amount_paid_now'], 0, ',', '.'); ?></td></tr>
    <tr><th><?php echo $t('Amount Remaining'); ?></th><td>Rp<?php echo number_format($booking['amount_remaining'], 0, ',', '.'); ?></td></tr>
    <tr><th><?php echo $t('Payment Status'); ?></th><td><?php echo htmlspecialchars($booking['payment_status']); ?></td></tr>
    <tr><th><?php echo $t('Booking Status'); ?></th><td><?php echo htmlspecialchars($booking['booking_status']); ?></td></tr>
</table>

<a class="btn" href="<?php echo base_url('admin/bookings'); ?>"><?php echo $t('Back'); ?></a>