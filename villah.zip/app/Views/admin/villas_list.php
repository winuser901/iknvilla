<?php
// Admin page listing villas with actions
?>
<h1><?php echo $t('Villas'); ?></h1>

<a class="btn" href="<?php echo base_url('admin/villas/create'); ?>">+ Add Villa</a>

<?php if (!empty($villas)): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th><?php echo $t('Name'); ?></th>
                <th><?php echo $t('City'); ?></th>
                <th><?php echo $t('Price per night'); ?></th>
                <th><?php echo $t('Action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($villas as $v): ?>
                <tr>
                    <td><?php echo (int)$v['id']; ?></td>
                    <td><?php echo htmlspecialchars($v['name_en']); ?></td>
                    <td><?php echo htmlspecialchars($v['city']); ?></td>
                    <td>Rp<?php echo number_format($v['base_price_per_night'], 0, ',', '.'); ?></td>
                    <td>
                        <a href="<?php echo base_url('admin/villas/edit/' . $v['id']); ?>">Edit</a> |
                        <a href="<?php echo base_url('admin/villas/delete/' . $v['id']); ?>" onclick="return confirm('Delete this villa?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p><?php echo $t('No villas found'); ?></p>
<?php endif; ?>