<?php
// Admin dashboard overview page
?>
<h1><?php echo $t('Dashboard Overview'); ?></h1>

<p><?php echo $t('Total Bookings'); ?>: <?php echo (int)$totalBookings; ?></p>
<p><?php echo $t('Total Revenue'); ?>: Rp<?php echo number_format($revenue ?? 0, 0, ',', '.'); ?></p>