<?php
// Admin package create/edit form
?>
<h1><?php echo $package ? 'Edit Package' : 'Add Package'; ?></h1>

<form method="POST" action="<?php echo base_url($package ? 'admin/packages/edit/' . $package['id'] : 'admin/packages/create'); ?>" enctype="multipart/form-data">
    <label for="name_id">Name (ID)</label>
    <input type="text" name="name_id" id="name_id" value="<?php echo htmlspecialchars($package['name_id'] ?? ''); ?>" required>
    <label for="name_en">Name (EN)</label>
    <input type="text" name="name_en" id="name_en" value="<?php echo htmlspecialchars($package['name_en'] ?? ''); ?>" required>
    <label for="slug">Slug</label>
    <input type="text" name="slug" id="slug" value="<?php echo htmlspecialchars($package['slug'] ?? ''); ?>">
    <label for="city">City</label>
    <input type="text" name="city" id="city" value="<?php echo htmlspecialchars($package['city'] ?? ''); ?>" required>
    <label for="duration_days">Duration (days)</label>
    <input type="number" name="duration_days" id="duration_days" value="<?php echo htmlspecialchars($package['duration_days'] ?? '1'); ?>" min="1" required>
    <label for="base_price_per_person">Base Price Per Person</label>
    <input type="number" name="base_price_per_person" id="base_price_per_person" value="<?php echo htmlspecialchars($package['base_price_per_person'] ?? ''); ?>" step="0.01" required>
    <label for="min_people">Min People</label>
    <input type="number" name="min_people" id="min_people" value="<?php echo htmlspecialchars($package['min_people'] ?? '1'); ?>" min="1" required>
    <label for="max_people">Max People</label>
    <input type="number" name="max_people" id="max_people" value="<?php echo htmlspecialchars($package['max_people'] ?? '10'); ?>" min="1" required>
    <label for="itinerary">Itinerary</label>
    <textarea name="itinerary" id="itinerary" rows="3"><?php echo htmlspecialchars($package['itinerary'] ?? ''); ?></textarea>
    <label for="inclusions">Inclusions (comma separated)</label>
    <input type="text" name="inclusions" id="inclusions" value="<?php echo htmlspecialchars($package['inclusions'] ?? ''); ?>">
    <label for="exclusions">Exclusions (comma separated)</label>
    <input type="text" name="exclusions" id="exclusions" value="<?php echo htmlspecialchars($package['exclusions'] ?? ''); ?>">
    <label for="description_id">Description (ID)</label>
    <textarea name="description_id" id="description_id" rows="4"><?php echo htmlspecialchars($package['description_id'] ?? ''); ?></textarea>
    <label for="description_en">Description (EN)</label>
    <textarea name="description_en" id="description_en" rows="4"><?php echo htmlspecialchars($package['description_en'] ?? ''); ?></textarea>
    <label for="image">Upload Image</label>
    <input type="file" name="image" id="image" accept="image/jpeg,image/png,image/webp">
    <button type="submit"><?php echo $package ? 'Update' : 'Create'; ?></button>
</form>

<a class="btn" href="<?php echo base_url('admin/packages'); ?>"><?php echo $t('Back'); ?></a>