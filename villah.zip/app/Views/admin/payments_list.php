<?php
// Admin page listing all payment proofs
?>
<h1><?php echo $t('Payments'); ?></h1>

<?php if (!empty($payments)): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th><?php echo $t('Booking Code'); ?></th>
                <th><?php echo $t('Payment Step'); ?></th>
                <th><?php echo $t('Amount'); ?></th>
                <th><?php echo $t('Method'); ?></th>
                <th><?php echo $t('Proof'); ?></th>
                <th><?php echo $t('Verification Status'); ?></th>
                <th><?php echo $t('Action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($payments as $p): ?>
                <tr>
                    <td><?php echo (int)$p['id']; ?></td>
                    <td><?php echo htmlspecialchars($p['booking_code']); ?></td>
                    <td><?php echo (int)$p['payment_step']; ?></td>
                    <td>Rp<?php echo number_format($p['amount'], 0, ',', '.'); ?></td>
                    <td><?php echo htmlspecialchars(strtoupper($p['method'])); ?></td>
                    <td>
                        <?php if ($p['proof_image']): ?>
                            <a href="<?php echo base_url('uploads/' . $p['proof_image']); ?>" target="_blank">View</a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($p['verification_status']); ?></td>
                    <td>
                        <?php if ($p['verification_status'] === 'PENDING'): ?>
                            <a class="btn" href="<?php echo base_url('admin/payments/verify/' . $p['id'] . '/APPROVED'); ?>"><?php echo $t('Approve'); ?></a>
                            <a class="btn" href="<?php echo base_url('admin/payments/verify/' . $p['id'] . '/REJECTED'); ?>"><?php echo $t('Reject'); ?></a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p><?php echo $t('No payments yet.'); ?></p>
<?php endif; ?>