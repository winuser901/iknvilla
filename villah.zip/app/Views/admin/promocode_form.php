<?php
// Admin create/edit promo code form
?>
<h1><?php echo $code ? 'Edit Promo Code' : 'Add Promo Code'; ?></h1>

<form method="POST" action="<?php echo base_url($code ? 'admin/promo-codes/edit/' . $code['id'] : 'admin/promo-codes/create'); ?>">
    <label for="code">Code</label>
    <input type="text" name="code" id="code" value="<?php echo htmlspecialchars($code['code'] ?? ''); ?>" required>
    <label for="description_id">Description (ID)</label>
    <textarea name="description_id" id="description_id" rows="3"><?php echo htmlspecialchars($code['description_id'] ?? ''); ?></textarea>
    <label for="description_en">Description (EN)</label>
    <textarea name="description_en" id="description_en" rows="3"><?php echo htmlspecialchars($code['description_en'] ?? ''); ?></textarea>
    <label for="discount_type">Discount Type</label>
    <select name="discount_type" id="discount_type">
        <option value="PERCENT" <?php echo (isset($code) && $code['discount_type'] === 'PERCENT') ? 'selected' : ''; ?>>Percent</option>
        <option value="FIXED" <?php echo (isset($code) && $code['discount_type'] === 'FIXED') ? 'selected' : ''; ?>>Fixed</option>
    </select>
    <label for="value">Value</label>
    <input type="number" name="value" id="value" value="<?php echo htmlspecialchars($code['value'] ?? '0'); ?>" step="0.01" required>
    <label for="max_uses">Max Uses</label>
    <input type="number" name="max_uses" id="max_uses" value="<?php echo htmlspecialchars($code['max_uses'] ?? '0'); ?>">
    <label for="valid_from">Valid From</label>
    <input type="date" name="valid_from" id="valid_from" value="<?php echo htmlspecialchars($code['valid_from'] ?? date('Y-m-d')); ?>">
    <label for="valid_until">Valid Until</label>
    <input type="date" name="valid_until" id="valid_until" value="<?php echo htmlspecialchars($code['valid_until'] ?? date('Y-m-d')); ?>">
    <label for="min_order_amount">Minimum Order Amount</label>
    <input type="number" name="min_order_amount" id="min_order_amount" value="<?php echo htmlspecialchars($code['min_order_amount'] ?? '0'); ?>" step="0.01">
    <label for="applicable_to">Applicable To</label>
    <select name="applicable_to" id="applicable_to">
        <option value="villa" <?php echo (isset($code) && $code['applicable_to'] === 'villa') ? 'selected' : ''; ?>>Villa</option>
        <option value="package" <?php echo (isset($code) && $code['applicable_to'] === 'package') ? 'selected' : ''; ?>>Package</option>
        <option value="both" <?php echo (!isset($code) || $code['applicable_to'] === 'both') ? 'selected' : ''; ?>>Both</option>
    </select>
    <label for="status">Status</label>
    <select name="status" id="status">
        <option value="active" <?php echo (!isset($code) || $code['status'] === 'active') ? 'selected' : ''; ?>>Active</option>
        <option value="inactive" <?php echo (isset($code) && $code['status'] === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
    </select>
    <button type="submit"><?php echo $code ? 'Update' : 'Create'; ?></button>
</form>

<a class="btn" href="<?php echo base_url('admin/promo-codes'); ?>"><?php echo $t('Back'); ?></a>