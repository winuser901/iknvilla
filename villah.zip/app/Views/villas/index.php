<?php
// Villas listing page
?>
<h1><?php echo $t('Villas'); ?></h1>

<form method="GET" class="filter-form">
    <label for="city"><?php echo $t('City'); ?>:</label>
    <input type="text" id="city" name="city" value="<?php echo htmlspecialchars($city ?? ''); ?>">
    <label for="q"><?php echo $t('Search'); ?>:</label>
    <input type="text" id="q" name="q" value="<?php echo htmlspecialchars($keyword ?? ''); ?>">
    <button type="submit"><?php echo $t('Search'); ?></button>
</form>

<?php if (!empty($villas)): ?>
    <div class="grid">
        <?php foreach ($villas as $v): ?>
            <div class="card" style="width: 30%; min-width: 250px;">
                <?php
                    // Use placeholder image; in real app load first from DB
                    $imgPath = 'assets/images/villa1.png';
                ?>
                <img src="<?php echo base_url($imgPath); ?>" alt="<?php echo htmlspecialchars($v['name_en']); ?>">
                <div class="card-body">
                    <h3 class="card-title">
                        <a href="<?php echo base_url('villas/' . $v['slug']); ?>">
                            <?php echo htmlspecialchars($v['name_' . ($_SESSION['lang'] ?? 'id')]); ?>
                        </a>
                    </h3>
                    <p class="card-text">
                        <?php echo $t('Price from'); ?> Rp<?php echo number_format($v['base_price_per_night'], 0, ',', '.'); ?>/<?php echo $t('night') ?? 'malam'; ?>
                    </p>
                    <a class="btn" href="<?php echo base_url('booking/villa/' . $v['id']); ?>">
                        <?php echo $t('Book Now'); ?>
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <p><?php echo $t('No villas found'); ?></p>
<?php endif; ?>

<style>
.filter-form {
    margin: 15px 0;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
}
.filter-form input {
    flex: 1;
    max-width: 200px;
}
.filter-form button {
    padding: 8px 12px;
    background-color: #004c3f;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
.filter-form button:hover {
    background-color: #007b5e;
}
@media (max-width: 600px) {
    .card {
        width: 100%;
    }
}
</style>