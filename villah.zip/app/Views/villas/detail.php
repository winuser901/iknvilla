<?php
// Villa detail page
?>
<h1><?php echo htmlspecialchars($villa['name_' . ($_SESSION['lang'] ?? 'id')]); ?></h1>

<p><strong><?php echo $t('Location'); ?>:</strong> <?php echo htmlspecialchars($villa['location']); ?>, <?php echo htmlspecialchars($villa['city']); ?></p>
<p><strong><?php echo $t('Price per night'); ?>:</strong> Rp<?php echo number_format($villa['base_price_per_night'], 0, ',', '.'); ?></p>
<p><strong><?php echo $t('Max guests'); ?>:</strong> <?php echo (int)$villa['max_guest']; ?></p>

<?php if (!empty($images)): ?>
    <h3><?php echo $t('Image Gallery'); ?></h3>
    <div class="gallery">
        <?php foreach ($images as $img): ?>
            <img src="<?php echo base_url($img['path']); ?>" alt="<?php echo htmlspecialchars($villa['name_en']); ?>" style="width: 100%; max-width: 300px; margin: 5px;">
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<h3><?php echo $t('Description'); ?></h3>
<p><?php echo nl2br(htmlspecialchars($villa['description_' . ($_SESSION['lang'] ?? 'id')])); ?></p>

<?php if ($villa['facilities']): ?>
<h3><?php echo $t('Facilities'); ?></h3>
<ul>
    <?php foreach (explode(',', $villa['facilities']) as $fac): ?>
        <li><?php echo htmlspecialchars(trim($fac)); ?></li>
    <?php endforeach; ?>
</ul>
<?php endif; ?>

<a class="btn" href="<?php echo base_url('booking/villa/' . $villa['id']); ?>"><?php echo $t('Book Now'); ?></a>

<style>
.gallery {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}
.gallery img {
    border: 1px solid #ddd;
    border-radius: 4px;
    object-fit: cover;
}
</style>