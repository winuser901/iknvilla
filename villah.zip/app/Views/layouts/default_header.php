<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($_SESSION['lang'] ?? 'en'); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $t('Villa & Holiday Booking'); ?></title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
<nav class="navbar">
    <div class="container">
        <a href="<?php echo base_url(); ?>" class="navbar-brand">Bali Booking</a>
        <ul class="nav-links">
            <li><a href="<?php echo base_url(); ?>"><?php echo $t('Home'); ?></a></li>
            <li><a href="<?php echo base_url('villas'); ?>"><?php echo $t('Villas'); ?></a></li>
            <li><a href="<?php echo base_url('packages'); ?>"><?php echo $t('Packages'); ?></a></li>
        </ul>
        <ul class="nav-actions">
            <?php if (is_logged_in()): ?>
                <li><a href="<?php echo base_url('dashboard'); ?>"><?php echo $t('Dashboard'); ?></a></li>
                <li><a href="<?php echo base_url('logout'); ?>"><?php echo $t('Logout'); ?></a></li>
            <?php else: ?>
                <li><a href="<?php echo base_url('login'); ?>"><?php echo $t('Login'); ?></a></li>
                <li><a href="<?php echo base_url('register'); ?>"><?php echo $t('Register'); ?></a></li>
            <?php endif; ?>
            <li class="lang-switch">
                <a href="<?php echo base_url('lang/id'); ?>" <?php if (($_SESSION['lang'] ?? 'id') === 'id') echo 'class="active"'; ?>>ID</a> |
                <a href="<?php echo base_url('lang/en'); ?>" <?php if (($_SESSION['lang'] ?? 'id') === 'en') echo 'class="active"'; ?>>EN</a>
            </li>
        </ul>
    </div>
</nav>
<main class="container">