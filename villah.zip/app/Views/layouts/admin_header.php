<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Bali Booking</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
<nav class="navbar admin-navbar">
    <div class="container">
        <a href="<?php echo base_url('admin/dashboard'); ?>" class="navbar-brand">Admin Panel</a>
        <ul class="nav-links">
            <li><a href="<?php echo base_url('admin/dashboard'); ?>">Dashboard</a></li>
            <li><a href="<?php echo base_url('admin/bookings'); ?>">Bookings</a></li>
            <li><a href="<?php echo base_url('admin/payments'); ?>">Payments</a></li>
        </ul>
        <ul class="nav-actions">
            <li><a href="<?php echo base_url('admin/logout'); ?>">Logout</a></li>
        </ul>
    </div>
</nav>
<main class="container">