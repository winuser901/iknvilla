    </main>
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Bali Booking Admin.</p>
        </div>
    </footer>
</body>
</html>