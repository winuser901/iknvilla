    </main>
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Bali Booking. All rights reserved.</p>
        </div>
    </footer>

    <?php
    // Render a mobile bottom navigation bar on public pages (non-admin). The
    // navigation is hidden for admin routes. Determine current URI to
    // highlight the active link.
    $currentPath = strtok($_SERVER['REQUEST_URI'], '?');
    $isAdminPage = (strpos($currentPath, '/admin') === 0);
    if (!$isAdminPage): ?>
    <nav class="mobile-bottom-nav">
        <?php
        // Determine active classes
        $homeActive    = ($currentPath === '/' ? 'active' : '');
        $exploreActive = (strpos($currentPath, '/villas') === 0 || strpos($currentPath, '/packages') === 0) ? 'active' : '';
        $ordersActive  = (strpos($currentPath, '/dashboard') === 0 || strpos($currentPath, '/booking/') === 0) ? 'active' : '';
        $savedActive   = (strpos($currentPath, '/profile') === 0) ? 'active' : '';
        ?>
        <a href="<?php echo base_url(); ?>" class="<?php echo $homeActive; ?>">
            <span class="icon">🏠</span>
            <span class="label"><?php echo $t('Home'); ?></span>
        </a>
        <a href="<?php echo base_url('villas'); ?>" class="<?php echo $exploreActive; ?>">
            <span class="icon">🔍</span>
            <span class="label"><?php echo $t('Explore'); ?></span>
        </a>
        <a href="<?php echo base_url('dashboard'); ?>" class="<?php echo $ordersActive; ?>">
            <span class="icon">📄</span>
            <span class="label"><?php echo $t('Bookings'); ?></span>
        </a>
        <a href="<?php echo base_url('profile'); ?>" class="<?php echo $savedActive; ?>">
            <span class="icon">💾</span>
            <span class="label"><?php echo $t('Saved'); ?></span>
        </a>
    </nav>
    <?php endif; ?>
</body>
</html>