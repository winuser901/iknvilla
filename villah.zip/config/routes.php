<?php
/**
 * Application routes
 *
 * Each entry in the routes array defines a HTTP method, a URI pattern and
 * a handler. Patterns are regular expressions anchored at the beginning and
 * end of the path. Captured segments are passed as parameters to the
 * controller method in the order they are defined. See core/Router.php for
 * details on how these patterns are matched.
 */

$routes = [
    // Public pages
    ['GET', '#^/$#', 'HomeController@index'],
    ['GET', '#^/villas$#', 'VillaController@index'],
    ['GET', '#^/villas/([a-z0-9\-]+)$#', 'VillaController@detail'],
    ['GET', '#^/packages$#', 'PackageController@index'],
    ['GET', '#^/packages/([a-z0-9\-]+)$#', 'PackageController@detail'],
    ['GET', '#^/lang/([a-z]{2})$#', 'HomeController@switchLang'],
    
    // Authentication
    ['GET', '#^/login$#', 'AuthController@loginForm'],
    ['POST', '#^/login$#', 'AuthController@login'],
    ['GET', '#^/register$#', 'AuthController@registerForm'],
    ['POST', '#^/register$#', 'AuthController@register'],
    ['GET', '#^/logout$#', 'AuthController@logout'],
    
    // Booking flow
    ['GET', '#^/booking/(villa|package)/([0-9]+)$#', 'BookingController@form'],
    ['POST', '#^/booking/(villa|package)/([0-9]+)$#', 'BookingController@create'],

    // Alias route to support legacy path with /create suffix. Some users may
    // still attempt to submit the booking form to /booking/{type}/{id}/create.
    // We map this POST request to the same create method to avoid a 404.
    ['POST', '#^/booking/(villa|package)/([0-9]+)/create$#', 'BookingController@create'],

    // Legacy GET path for booking form with /create suffix. Redirects to the same
    // booking form as without /create to prevent 404 when users manually append /create.
    ['GET', '#^/booking/(villa|package)/([0-9]+)/create$#', 'BookingController@form'],
    ['GET', '#^/booking/([A-Z0-9]+)$#', 'BookingController@invoice'],
    ['GET', '#^/booking/([A-Z0-9]+)/upload-proof$#', 'BookingController@uploadProofForm'],
    ['POST', '#^/booking/([A-Z0-9]+)/upload-proof$#', 'BookingController@uploadProof'],
    
    // Customer pages (requires login)
    ['GET', '#^/dashboard$#', 'UserController@dashboard'],
    ['GET', '#^/profile$#', 'UserController@profileForm'],
    ['POST', '#^/profile$#', 'UserController@profileUpdate'],
    
    // Admin authentication
    ['GET', '#^/admin/login$#', 'Admin\\AdminController@loginForm'],
    ['POST', '#^/admin/login$#', 'Admin\\AdminController@login'],
    ['GET', '#^/admin/logout$#', 'Admin\\AdminController@logout'],
    
    // Admin dashboard
    ['GET', '#^/admin$#', 'Admin\\AdminController@dashboard'],
    ['GET', '#^/admin/dashboard$#', 'Admin\\AdminController@dashboard'],
    
    // Admin – villas CRUD
    ['GET', '#^/admin/villas$#', 'Admin\\VillasController@index'],
    ['GET', '#^/admin/villas/create$#', 'Admin\\VillasController@createForm'],
    ['POST', '#^/admin/villas/create$#', 'Admin\\VillasController@create'],
    ['GET', '#^/admin/villas/edit/([0-9]+)$#', 'Admin\\VillasController@editForm'],
    ['POST', '#^/admin/villas/edit/([0-9]+)$#', 'Admin\\VillasController@update'],
    ['GET', '#^/admin/villas/delete/([0-9]+)$#', 'Admin\\VillasController@delete'],
    
    // Admin – packages CRUD
    ['GET', '#^/admin/packages$#', 'Admin\\PackagesController@index'],
    ['GET', '#^/admin/packages/create$#', 'Admin\\PackagesController@createForm'],
    ['POST', '#^/admin/packages/create$#', 'Admin\\PackagesController@create'],
    ['GET', '#^/admin/packages/edit/([0-9]+)$#', 'Admin\\PackagesController@editForm'],
    ['POST', '#^/admin/packages/edit/([0-9]+)$#', 'Admin\\PackagesController@update'],
    ['GET', '#^/admin/packages/delete/([0-9]+)$#', 'Admin\\PackagesController@delete'],
    
    // Admin – bookings management
    ['GET', '#^/admin/bookings$#', 'Admin\\BookingsController@index'],
    ['GET', '#^/admin/bookings/view/([0-9]+)$#', 'Admin\\BookingsController@view'],
    ['GET', '#^/admin/bookings/status/([0-9]+)/([A-Z_]+)$#', 'Admin\\BookingsController@updateStatus'],
    
    // Admin – payments management
    ['GET', '#^/admin/payments$#', 'Admin\\PaymentsController@index'],
    ['GET', '#^/admin/payments/verify/([0-9]+)/([A-Z]+)$#', 'Admin\\PaymentsController@verify'],
    
    // Admin – promo codes management
    ['GET', '#^/admin/promo-codes$#', 'Admin\\PromoCodesController@index'],
    ['GET', '#^/admin/promo-codes/create$#', 'Admin\\PromoCodesController@createForm'],
    ['POST', '#^/admin/promo-codes/create$#', 'Admin\\PromoCodesController@create'],
    ['GET', '#^/admin/promo-codes/edit/([0-9]+)$#', 'Admin\\PromoCodesController@editForm'],
    ['POST', '#^/admin/promo-codes/edit/([0-9]+)$#', 'Admin\\PromoCodesController@update'],
    ['GET', '#^/admin/promo-codes/delete/([0-9]+)$#', 'Admin\\PromoCodesController@delete'],

    // Commented out discount rules, users and settings routes for brevity

];

// Return the routes array so that including this file returns the list of routes
return $routes;