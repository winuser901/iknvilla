<?php
/**
 * Application configuration
 *
 * This file contains general settings used throughout the application. Values
 * are read from the environment (.env) where available. If an environment
 * variable is not set a sensible default is used. When adding new
 * configuration items remember to document them here.
 */

return [
    // Base URL of the application. Trailing slash is required. This value
    // determines how links and redirects are generated. When deploying to
    // production change this to the appropriate domain.
    'base_url' => $_ENV['APP_BASE_URL'] ?? 'http://localhost:8080/',

    // Default locale/language used when the user has not explicitly selected
    // a language. Valid values correspond to subdirectory names in
    // app/Language. See the official CodeIgniter documentation for how
    // locales operate【335700859490052†L231-L259】.
    'default_language' => 'id',

    // Languages supported by the UI. This array is used when switching
    // languages to ensure only valid locales are accepted. Additional
    // languages can be added by creating a new folder under app/Language
    // and adding it to this array.
    'supported_languages' => ['id', 'en'],

    // Currency used for display and pricing. All monetary values in the
    // application are assumed to be in Indonesian Rupiah (IDR) by default.
    'currency' => 'IDR',

    // Timezone used across the application. If not set via the .env file
    // this will default to Asia/Jakarta, aligning with the user's locale.
    'timezone' => $_ENV['TIMEZONE'] ?? 'Asia/Jakarta',

    // Payment options determine what percentage of the grand total must be
    // paid immediately. The keys correspond to internal codes stored in
    // bookings.payment_option. Values represent multipliers to calculate
    // amount_paid_now. For example, DP75 means the customer pays 75% now and
    // the remainder later.
    'payment_options' => [
        'FULL' => 1.00,
        'DP75' => 0.75,
        'DP50' => 0.50,
    ],
];