<?php
/**
 * Database configuration
 *
 * Defines the connection parameters used by the PDO instance in
 * core/Model.php. Values are read from environment variables with
 * sensible defaults for local development. Adjust these settings
 * according to your deployment environment (e.g. Docker, cPanel).
 */

return [
    'host'     => $_ENV['DB_HOST'] ?? 'localhost',
    'dbname'   => $_ENV['DB_NAME'] ?? 'villa_holiday_booking',
    'username' => $_ENV['DB_USER'] ?? 'root',
    'password' => $_ENV['DB_PASS'] ?? '',
    'charset'  => 'utf8mb4',
];