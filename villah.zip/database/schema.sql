-- SQL schema for Villa & Holiday Package Booking Application

-- Users table stores login credentials and basic profile information. Roles
-- include 'customer' for regular guests, 'admin' for administrators and
-- optional finance/super admin roles. Preferred language allows us to
-- remember the user's UI language choice. Status indicates whether the
-- account is active. Passwords are stored as hashes using PHP's
-- password_hash() function.
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('customer','admin','finance') NOT NULL DEFAULT 'customer',
  preferred_language ENUM('id','en') NOT NULL DEFAULT 'id',
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Villas table holds the primary information for each property. Names and
-- descriptions are stored in both Indonesian (name_id, description_id) and
-- English (name_en, description_en) so that the frontend can display
-- content based on the selected language. Slugs provide SEO‑friendly
-- identifiers used in URLs. Facilities and tags are stored as comma
-- separated lists for simplicity. A status field allows deactivating a
-- listing without deleting it.
CREATE TABLE IF NOT EXISTS villas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name_id VARCHAR(255) NOT NULL,
  name_en VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NOT NULL UNIQUE,
  location VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL,
  country VARCHAR(100) NOT NULL DEFAULT 'Indonesia',
  max_guest INT NOT NULL,
  base_price_per_night DECIMAL(12,2) NOT NULL,
  facilities TEXT,
  tags VARCHAR(255),
  video_url VARCHAR(255),
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  description_id TEXT,
  description_en TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Each villa can have multiple images. The path field stores the relative
-- location of the file on disk. Deleting a villa should cascade to its
-- associated images.
CREATE TABLE IF NOT EXISTS villa_images (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  villa_id INT UNSIGNED NOT NULL,
  path VARCHAR(255) NOT NULL,
  FOREIGN KEY (villa_id) REFERENCES villas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Holiday packages table. Similar to villas, names and descriptions are
-- duplicated per language. Duration is stored as the number of days. The
-- itinerary field can hold a JSON or plain text description of the trip.
CREATE TABLE IF NOT EXISTS packages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name_id VARCHAR(255) NOT NULL,
  name_en VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NOT NULL UNIQUE,
  city VARCHAR(100) NOT NULL,
  duration_days INT NOT NULL,
  base_price_per_person DECIMAL(12,2) NOT NULL,
  min_people INT NOT NULL,
  max_people INT NOT NULL,
  itinerary TEXT,
  inclusions TEXT,
  exclusions TEXT,
  video_url VARCHAR(255),
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  description_id TEXT,
  description_en TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Images associated with holiday packages.
CREATE TABLE IF NOT EXISTS package_images (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  package_id INT UNSIGNED NOT NULL,
  path VARCHAR(255) NOT NULL,
  FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Bookings table tracks every reservation. The type field indicates
-- whether the booking is for a villa or a package. The reference_id
-- refers to either the villas.id or packages.id depending on the type.
-- Subtotal is the price before discounts, discount_amount reflects the
-- total discounts applied, and grand_total is the final price. Payment
-- option indicates whether the customer chose to pay 100%, 75% or 50%
-- upfront. The amount_paid_now and amount_remaining fields help drive
-- payment flows. Due_date_remaining marks when the outstanding balance
-- must be settled. Various status fields capture the state of the
-- booking and payment.
CREATE TABLE IF NOT EXISTS bookings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  booking_code VARCHAR(20) NOT NULL UNIQUE,
  user_id INT UNSIGNED NOT NULL,
  type ENUM('villa','package') NOT NULL,
  reference_id INT UNSIGNED NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE,
  participants INT NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL,
  discount_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  grand_total DECIMAL(12,2) NOT NULL,
  payment_option ENUM('FULL','DP75','DP50') NOT NULL,
  amount_paid_now DECIMAL(12,2) NOT NULL,
  amount_remaining DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  due_date_remaining DATE,
  payment_status ENUM('UNPAID','PARTIAL','PAID','CANCELLED') NOT NULL DEFAULT 'UNPAID',
  booking_status ENUM('PENDING_CONFIRMATION','CONFIRMED','CANCELLED','COMPLETED') NOT NULL DEFAULT 'PENDING_CONFIRMATION',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Payments table records each transaction related to a booking. The
-- payment_step value helps differentiate between the first and second
-- payments in partial payment scenarios. Verification status allows
-- administrators to approve or reject payment proofs. Notes can
-- capture feedback or reasons when rejecting a payment.
CREATE TABLE IF NOT EXISTS payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  booking_id INT UNSIGNED NOT NULL,
  payment_step TINYINT NOT NULL,
  method ENUM('bank_transfer','qris') NOT NULL DEFAULT 'bank_transfer',
  amount DECIMAL(12,2) NOT NULL,
  proof_image VARCHAR(255),
  paid_at DATETIME,
  verified_by INT UNSIGNED,
  verification_status ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  notes TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  FOREIGN KEY (verified_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Promo codes table provides support for coupon‑style discounts. The
-- discount_type determines whether the value is interpreted as a
-- percentage or a fixed amount. The min_order_amount prevents the
-- discount from being applied to small orders. The applicable_to field
-- restricts the promotion to villas, packages or both. Use the
-- status field to deactivate expired or suspended codes. The
-- used_count helps enforce maximum usage.
CREATE TABLE IF NOT EXISTS promo_codes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(50) NOT NULL UNIQUE,
  description_id TEXT,
  description_en TEXT,
  discount_type ENUM('PERCENT','FIXED') NOT NULL,
  value DECIMAL(12,2) NOT NULL,
  max_uses INT NOT NULL DEFAULT 0,
  used_count INT NOT NULL DEFAULT 0,
  valid_from DATE NOT NULL,
  valid_until DATE NOT NULL,
  min_order_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  applicable_to ENUM('villa','package','both') NOT NULL DEFAULT 'both',
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Discount rules table stores automatic discount configurations such as
-- early bird or last minute. The type field identifies the rule. For
-- early bird discounts, days_before determines how many days prior to
-- the start date the booking must be placed. For last minute
-- discounts, days_within indicates how close to the start date the
-- booking must be. Only one of days_before or days_within will be
-- applicable per rule. Value and discount_type describe the discount.
CREATE TABLE IF NOT EXISTS discount_rules (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  rule_name VARCHAR(100) NOT NULL,
  description_id TEXT,
  description_en TEXT,
  type ENUM('early_bird','last_minute','seasonal') NOT NULL,
  days_before INT,
  days_within INT,
  discount_type ENUM('PERCENT','FIXED') NOT NULL,
  value DECIMAL(12,2) NOT NULL,
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Application settings table allows storing miscellaneous key/value
-- pairs such as bank account details or QRIS image paths.
CREATE TABLE IF NOT EXISTS settings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  setting_value TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Example seed data. Insert sample villas, packages and promo codes. The
-- descriptions use simple placeholder text in Indonesian and English. In
-- a real deployment you would likely populate these tables via the admin
-- interface.

-- Sample users: create a default admin and a demo customer. Passwords
-- should be generated using password_hash('secret', PASSWORD_DEFAULT) before
-- inserting. Here we provide plain hashes for demonstration. Replace
-- them with your own secure hashes.
INSERT INTO users (name, email, phone, password_hash, role, preferred_language)
VALUES
  ('Admin', 'admin@example.com', '08123456789', '$2y$10$examplehashforadmin1234567890', 'admin', 'en'),
  ('Demo User', 'user@example.com', '08129876543', '$2y$10$examplehashforuser1234567890', 'customer', 'id');

-- Sample villas
INSERT INTO villas (name_id, name_en, slug, location, city, max_guest, base_price_per_night, facilities, tags, description_id, description_en)
VALUES
  ('Villa Indah', 'Beautiful Villa', 'beautiful-villa', 'Ubud', 'Bali', 4, 2500000.00, 'Kolam renang, WiFi gratis, Sarapan', 'mewah,ubud', 'Sebuah vila mewah di Ubud dengan pemandangan sawah dan kolam renang pribadi.', 'A luxurious villa in Ubud with rice field views and a private pool.'),
  ('Villa Pantai', 'Beach Villa', 'beach-villa', 'Seminyak', 'Bali', 6, 3500000.00, 'Akses pantai, AC, WiFi', 'pantai,romantis', 'Vila di tepi pantai dengan akses langsung ke pantai pasir putih.', 'Beachfront villa with direct access to a white sand beach.'),
  ('Villa Keluarga', 'Family Villa', 'family-villa', 'Canggu', 'Bali', 8, 3000000.00, 'Dapur lengkap, Kolam renang, WiFi', 'keluarga,tenang', 'Vila luas untuk keluarga dengan fasilitas lengkap di Canggu.', 'Spacious family villa with full amenities located in Canggu.');

-- Sample packages
INSERT INTO packages (name_id, name_en, slug, city, duration_days, base_price_per_person, min_people, max_people, itinerary, inclusions, exclusions, description_id, description_en)
VALUES
  ('Paket Bulan Madu', 'Honeymoon Package', 'honeymoon-package', 'Bali', 4, 4000000.00, 2, 2, 'Hari 1: Tiba dan check-in; Hari 2: Tur Ubud; Hari 3: Spa; Hari 4: Bebas', 'Akomodasi, Transportasi, Spa', 'Tiket pesawat, Makan siang', 'Paket romantis untuk pasangan baru menikah dengan aktivitas santai.', 'A romantic package for newlyweds featuring relaxing activities.'),
  ('Paket Keluarga', 'Family Package', 'family-package', 'Bali', 3, 2500000.00, 4, 10, 'Hari 1: Pantai; Hari 2: Waterpark; Hari 3: Belanja', 'Hotel, Makan pagi, Tiket masuk', 'Transportasi ke Bali', 'Paket liburan keluarga dengan aktivitas seru untuk anak-anak.', 'Family holiday package with fun activities for children.'),
  ('Paket Petualangan', 'Adventure Package', 'adventure-package', 'Bali', 5, 3000000.00, 2, 8, 'Hari 1: Hiking; Hari 2: Rafting; Hari 3: Bersepeda; Hari 4: Arung jeram; Hari 5: Bebas', 'Penginapan, Pemandu, Peralatan', 'Asuransi perjalanan', 'Paket untuk pecinta petualangan dengan aktivitas outdoor.', 'Package for adventure lovers featuring outdoor activities.');

-- Sample promo codes
INSERT INTO promo_codes (code, description_id, description_en, discount_type, value, max_uses, valid_from, valid_until, min_order_amount, applicable_to)
VALUES
  ('EARLYBIRD10', 'Diskon 10% untuk pemesanan awal', '10% discount for early bookings', 'PERCENT', 10.00, 100, '2025-01-01', '2026-12-31', 5000000.00, 'both'),
  ('SUMMER20', 'Diskon musim panas 20%', '20% summer discount', 'PERCENT', 20.00, 50, '2025-06-01', '2025-09-30', 7000000.00, 'villa'),
  ('FIXED500', 'Diskon Rp500.000 untuk paket', 'Rp500,000 off for packages', 'FIXED', 500000.00, 50, '2025-01-01', '2026-01-31', 3000000.00, 'package');