<?php
// Front controller for Bali Booking App

// Start session
session_start();

// Simple PSR-4 like autoloader for controllers, models and core classes
spl_autoload_register(function ($class) {
    /*
     * PSR-4 like autoloader for the micro‑framework.
     *
     * We map the namespace prefixes to the corresponding directories:
     *   App\Controllers\ → app/Controllers/
     *   App\Models\      → app/Models/
     * Core classes        → core/
     */
    // Controllers
    if (strpos($class, 'App\\Controllers\\') === 0) {
        $relative = substr($class, strlen('App\\Controllers\\'));
        $controllerPath = __DIR__ . '/app/Controllers/' . str_replace('\\', '/', $relative) . '.php';
        if (file_exists($controllerPath)) {
            require_once $controllerPath;
            return;
        }
    }
    // Models
    if (strpos($class, 'App\\Models\\') === 0) {
        $relative = substr($class, strlen('App\\Models\\'));
        $modelPath = __DIR__ . '/app/Models/' . str_replace('\\', '/', $relative) . '.php';
        if (file_exists($modelPath)) {
            require_once $modelPath;
            return;
        }
    }
    // Core classes (non-namespaced)
    $corePath = __DIR__ . '/core/' . $class . '.php';
    if (file_exists($corePath)) {
        require_once $corePath;
        return;
    }
});

// Load helpers
require_once __DIR__ . '/helpers/url_helper.php';
require_once __DIR__ . '/helpers/i18n_helper.php';
require_once __DIR__ . '/helpers/auth_helper.php';

// Load routes
$routes = require __DIR__ . '/config/routes.php';

// Instantiate router
$router = new Router($routes);

// Determine request method and URI
$method = $_SERVER['REQUEST_METHOD'];
$uri = $_SERVER['REQUEST_URI'];

// Remove query string
if (false !== $pos = strpos($uri, '?')) {
    $uri = substr($uri, 0, $pos);
}

// Remove base path if application is served in subdirectory
$config = require __DIR__ . '/config/config.php';
$basePath = parse_url($config['base_url'], PHP_URL_PATH);
if ($basePath && $basePath !== '/' && strpos($uri, $basePath) === 0) {
    $uri = substr($uri, strlen($basePath));
    if ($uri === '') {
        $uri = '/';
    }
}

// Dispatch the request
$router->dispatch($uri, $method);