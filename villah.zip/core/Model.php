<?php
/**
 * Base Model
 *
 * Provides a lightweight wrapper around PDO for executing queries and
 * performing CRUD operations. Individual model classes extend this
 * class and specify the table name and primary key.
 */
abstract class Model
{
    /** @var \PDO */
    protected static $pdo;

    /** @var string */
    protected $table;

    /** @var string */
    protected $primaryKey = 'id';

    public function __construct()
    {
        if (!self::$pdo) {
            $this->connect();
        }
    }

    /**
     * Establish a PDO connection using config/database.php. The connection
     * is stored in a static property so that all model instances share
     * the same connection, reducing overhead.
     */
    protected function connect(): void
    {
        $db = require __DIR__ . '/../config/database.php';
        $dsn = 'mysql:host=' . $db['host'] . ';dbname=' . $db['dbname'] . ';charset=' . $db['charset'];
        try {
            self::$pdo = new \PDO($dsn, $db['username'], $db['password'], [
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            ]);
        } catch (\PDOException $e) {
            die('Database connection error: ' . $e->getMessage());
        }
    }

    /**
     * Execute a query with optional bound parameters and return the PDO
     * statement. Used internally by other methods.
     *
     * @param string $sql
     * @param array  $params
     *
     * @return \PDOStatement
     */
    protected function query(string $sql, array $params = []): \PDOStatement
    {
        $stmt = self::$pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /**
     * Find a single record by its primary key. Returns an associative
     * array or null if nothing is found.
     *
     * @param mixed $id
     *
     * @return array|null
     */
    public function find($id): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id LIMIT 1";
        $stmt = $this->query($sql, ['id' => $id]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    /**
     * Retrieve multiple records with optional conditions and ordering. When
     * no conditions are provided all records are returned. Limit and
     * offset support pagination.
     *
     * @param array  $conditions Associative array of column => value pairs
     * @param string $orderBy    SQL order clause (e.g. "created_at DESC")
     * @param int    $limit      Maximum number of rows
     * @param int    $offset     Offset for pagination
     *
     * @return array
     */
    public function findAll(array $conditions = [], string $orderBy = '', int $limit = 0, int $offset = 0): array
    {
        $sql = "SELECT * FROM {$this->table}";
        $params = [];
        if ($conditions) {
            $clauses = [];
            foreach ($conditions as $col => $val) {
                $clauses[] = "$col = :$col";
                $params[$col] = $val;
            }
            $sql .= ' WHERE ' . implode(' AND ', $clauses);
        }
        if ($orderBy) {
            $sql .= ' ORDER BY ' . $orderBy;
        }
        if ($limit > 0) {
            $sql .= ' LIMIT ' . $limit;
            if ($offset > 0) {
                $sql .= ' OFFSET ' . $offset;
            }
        }
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }

    /**
     * Insert a new record. Returns the insert ID on success.
     *
     * @param array $data
     *
     * @return int
     */
    public function insert(array $data): int
    {
        $columns = array_keys($data);
        $placeholders = array_map(fn($c) => ':' . $c, $columns);
        $sql = 'INSERT INTO ' . $this->table . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', $placeholders) . ')';
        $this->query($sql, $data);
        return (int)self::$pdo->lastInsertId();
    }

    /**
     * Update a record by primary key. Returns the number of affected rows.
     *
     * @param mixed $id
     * @param array $data
     *
     * @return int
     */
    public function update($id, array $data): int
    {
        $assignments = [];
        foreach ($data as $col => $val) {
            $assignments[] = "$col = :$col";
        }
        $data[$this->primaryKey] = $id;
        $sql = 'UPDATE ' . $this->table . ' SET ' . implode(',', $assignments) . ' WHERE ' . $this->primaryKey . ' = :' . $this->primaryKey;
        $stmt = $this->query($sql, $data);
        return $stmt->rowCount();
    }

    /**
     * Delete a record by primary key. Returns the number of affected rows.
     *
     * @param mixed $id
     *
     * @return int
     */
    public function delete($id): int
    {
        $sql = 'DELETE FROM ' . $this->table . ' WHERE ' . $this->primaryKey . ' = :id';
        $stmt = $this->query($sql, ['id' => $id]);
        return $stmt->rowCount();
    }
}