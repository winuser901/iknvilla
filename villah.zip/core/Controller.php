<?php
/**
 * Base Controller
 *
 * Provides common functionality for all controllers such as loading
 * configuration, handling sessions, rendering views and managing
 * translations. Application controllers should extend this class.
 */
abstract class Controller
{
    /** @var array */
    protected $config;

    /** @var array */
    protected $lang;

    public function __construct()
    {
        // Load global configuration
        $this->config = require __DIR__ . '/../config/config.php';
        // Ensure timezone is set early
        date_default_timezone_set($this->config['timezone'] ?? 'Asia/Jakarta');
        // Load translations for the current locale
        $this->loadLanguage();
    }

    /**
     * Load the appropriate language file based on session or default. The
     * language is stored in $_SESSION['lang'] and falls back to
     * config['default_language'] when absent. Language files live in
     * app/Language/{locale}/messages.php and return an associative array
     * of translation keys. Missing keys return the key itself.
     */
    protected function loadLanguage(): void
    {
        $locale = $_SESSION['lang'] ?? $this->config['default_language'];
        // Validate locale
        if (!in_array($locale, $this->config['supported_languages'], true)) {
            $locale = $this->config['default_language'];
        }
        $langFile = __DIR__ . '/../app/Language/' . $locale . '/messages.php';
        if (file_exists($langFile)) {
            $this->lang = require $langFile;
        } else {
            $this->lang = [];
        }
    }

    /**
     * Translate a key into the current language. If the key does not exist
     * in the language array the key itself will be returned, making it
     * obvious when translations are missing.
     *
     * @param string $key
     *
     * @return string
     */
    protected function t(string $key): string
    {
        return $this->lang[$key] ?? $key;
    }

    /**
     * Render a view within the optional layout. Data passed to the view is
     * extracted so that variables are available within the included file.
     *
     * @param string $view   Relative path under app/Views without .php
     * @param array  $data   Associative array of variables for the view
     * @param string $layout Layout name under app/Views/layouts
     */
    protected function render(string $view, array $data = [], string $layout = 'default'): void
    {
        $viewFile = __DIR__ . '/../app/Views/' . $view . '.php';
        $layoutHeader = __DIR__ . '/../app/Views/layouts/' . $layout . '_header.php';
        $layoutFooter = __DIR__ . '/../app/Views/layouts/' . $layout . '_footer.php';
        if (!file_exists($viewFile)) {
            throw new \RuntimeException('View not found: ' . $viewFile);
        }
        // Make translation helper available inside view
        $t = fn($k) => $this->t($k);
        // Extract data variables
        extract($data);
        // Include header, view and footer
        if (file_exists($layoutHeader)) {
            include $layoutHeader;
        }
        include $viewFile;
        if (file_exists($layoutFooter)) {
            include $layoutFooter;
        }
    }

    /**
     * Redirect to a relative or absolute URL. Uses base_url when provided
     * a relative path. After sending the header the script exits to
     * prevent further output.
     *
     * @param string $uri
     */
    protected function redirect(string $uri): void
    {
        // Prepend base URL if relative
        if (strpos($uri, 'http') !== 0) {
            $uri = rtrim($this->config['base_url'], '/') . '/' . ltrim($uri, '/');
        }
        header('Location: ' . $uri);
        exit;
    }

    /**
     * Return the base URL from configuration.
     *
     * @return string
     */
    protected function baseUrl(): string
    {
        return $this->config['base_url'];
    }
}