<?php
/**
 * Simple router
 *
 * This class is responsible for parsing the incoming request URI and
 * dispatching it to the appropriate controller and method based on the
 * patterns defined in config/routes.php. It supports named parameters
 * through regular expression capture groups. Inspired by CodeIgniter's
 * routing but implemented in a lightweight manner suitable for this
 * micro‑framework.
 */
class Router
{
    /**
     * Array of route definitions. Each entry must contain the HTTP method,
     * a regex pattern (anchored), and a handler string in the form
     * Controller@method. When a request matches a pattern, the handler
     * will be invoked with captured parameters.
     *
     * @var array
     */
    protected $routes;

    public function __construct(array $routes)
    {
        $this->routes = $routes;
    }

    /**
     * Dispatch the incoming request to a controller method.
     *
     * @param string $uri    The request URI (e.g. /villas/beautiful-villa)
     * @param string $method HTTP verb (GET, POST)
     */
    public function dispatch(string $uri, string $method)
    {
        // Strip query string and decode URL
        $path = parse_url($uri, PHP_URL_PATH);

        foreach ($this->routes as $route) {
            [$httpMethod, $pattern, $handler] = $route;
            if ($httpMethod !== $method) {
                continue;
            }
            if (preg_match($pattern, $path, $matches)) {
                // Remove the full match
                array_shift($matches);
                $this->invokeHandler($handler, $matches);
                return;
            }
        }
        // No match – show 404 error page
        http_response_code(404);
        echo '<h1>404 Not Found</h1>';
        echo '<p>The page you requested could not be found.</p>';
    }

    /**
     * Instantiate the controller and call the method with parameters.
     *
     * @param string $handler e.g. 'HomeController@index' or 'Admin\\VillasController@create'
     * @param array  $params  Captured parameters from the URI
     */
    protected function invokeHandler(string $handler, array $params)
    {
        if (strpos($handler, '@') === false) {
            throw new \InvalidArgumentException('Invalid handler definition: ' . $handler);
        }
        [$class, $method] = explode('@', $handler);
        // Handle namespaced controllers (admin)
        $class = $this->resolveControllerClass($class);
        if (!class_exists($class)) {
            // Attempt to load controller file by removing the base namespace
            $relative = $class;
            // Strip the App\Controllers\ prefix if present
            if (strpos($relative, 'App\\Controllers\\') === 0) {
                $relative = substr($relative, strlen('App\\Controllers\\'));
            }
            $path = __DIR__ . '/../app/Controllers/' . str_replace('\\', '/', $relative) . '.php';
            if (file_exists($path)) {
                require_once $path;
            }
        }
        if (!class_exists($class)) {
            throw new \RuntimeException('Controller not found: ' . $class);
        }
        $controller = new $class();
        if (!method_exists($controller, $method)) {
            throw new \RuntimeException('Method ' . $method . ' not found in controller ' . $class);
        }
        call_user_func_array([$controller, $method], $params);
    }

    /**
     * Resolve controller class name to include namespace for admin controllers.
     * Admin controllers live under the Admin namespace within app/Controllers.
     *
     * @param string $class Raw class name from route definition
     *
     * @return string Fully qualified class name
     */
    protected function resolveControllerClass(string $class): string
    {
        /*
         * Resolve controller class name to fully qualified namespace.
         *
         * All controllers live under the App\Controllers namespace.
         * Admin controllers are nested under App\Controllers\Admin.
         * For example:
         *   "HomeController"      → "App\\Controllers\\HomeController"
         *   "Admin\\VillasController" → "App\\Controllers\\Admin\\VillasController"
         */
        $baseNamespace = 'App\\Controllers\\';
        if (strpos($class, 'Admin\\') === 0) {
            // Prepend base namespace if not already fully qualified
            return $baseNamespace . $class;
        }
        return $baseNamespace . $class;
    }
}