# Bali Booking – Full‑Stack Villa & Holiday Package Booking App

This repository contains a complete full‑stack web application for booking luxury villas and curated holiday packages in Bali.  The project is built using a lightweight PHP micro‑framework inspired by CodeIgniter 4 but implemented from scratch to avoid external dependencies.  It supports multi‑language (Bahasa Indonesia and English), flexible discount rules, partial payments and a responsive admin dashboard.

## Features

- **User Roles** – Guests can browse listings without logging in.  Registered users/customers can book villas and packages, view their booking history and update their profile.  Administrators manage content and verify payments.
- **Multi‑language UI** – All static texts, form labels, validation messages and email templates support Indonesian (`id`) and English (`en`).  Users can switch language via the navbar and the preference is stored in the session.
- **Villas & Packages** – Each villa/package record stores names and descriptions in both languages along with pricing, facilities and multiple images.  Listings can be filtered by city or searched by keyword.  Detail pages include photo galleries and booking call‑to‑actions.
- **Booking & Pricing Logic** – Customers pick dates and number of guests/participants.  The system calculates subtotal, applies promo codes and seasonal discounts, and allows the customer to choose full or partial payment (100 %, 75 % or 50 %).  Unique booking codes and invoices are generated.
- **Payment Flow** – Payment is assumed to be manual via bank transfer or QRIS.  Customers see payment instructions and upload proof of payment.  Administrators approve or reject proofs which updates booking statuses accordingly.
- **Discounts & Promo Codes** – Admins can create percentage or fixed discounts with validity periods, usage limits and minimum order amounts.  Discount rules (early bird/last minute) can be added via the `discount_rules` table and applied automatically in the booking model.
- **Admin Dashboard** – Responsive admin interface for managing villas, packages and promo codes, viewing bookings and verifying payments.  KPIs such as total bookings and revenue are shown on the dashboard.
- **Security & Validation** – All user inputs are validated on the server.  Passwords are hashed.  Admin routes are protected via role checks.  File uploads are restricted to images and limited in size.  CSRF tokens can be added via hidden inputs if needed.

## Project Structure

```
villa_booking_app/
├── app/                 # Application code
│   ├── Controllers/     # Controllers (public and admin)
│   ├── Models/          # ORM‑like models
│   ├── Views/           # View templates (multi‑language aware)
│   └── Language/        # Translation files for en/ and id/
├── config/              # Configuration files (base URL, DB, routes)
├── core/                # Lightweight MVC core (Router, Controller, Model)
├── database/            # MySQL schema with seed data
├── helpers/             # Helper functions (auth, i18n, URL)
├── public/              # Public assets (CSS, images)
├── uploads/             # Uploaded proof images and media
├── .env                 # Example environment variables
├── index.php            # Front controller
└── README.md            # Documentation (this file)
```

## Installation

1. **Clone the repository** and navigate into the `villa_booking_app` directory:

   ```bash
   git clone <repo-url>
   cd villa_booking_app
   ```

2. **Create the MySQL database** using the provided schema.  The database name defaults to `villa_holiday_booking`.  Import `database/schema.sql` into your MySQL server:

   ```bash
   mysql -u root -p -e "CREATE DATABASE villa_holiday_booking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
   mysql -u root -p villa_holiday_booking < database/schema.sql
   ```

3. **Configure environment variables**.  Copy `.env` to your own environment or edit it directly to match your setup (database credentials, base URL, timezone):

   ```env
   APP_BASE_URL=http://localhost:8080/
   DB_HOST=localhost
   DB_NAME=villa_holiday_booking
   DB_USER=root
   DB_PASS=
   TIMEZONE=Asia/Jakarta
   ```

4. **Serve the application** using PHP’s built‑in server or configure your web server to point to the project root (not the `public` directory because the front controller lives at the root).  When using the built‑in server run:

   ```bash
   php -S localhost:8080 -t villa_booking_app
   ```

   Visiting `http://localhost:8080/` will load the landing page.  Adjust the port as needed.

## Usage

- **Language Selection** – Use the “ID/EN” toggle in the top navigation bar to switch languages.  The selected language is stored in the session.
- **Register/Login** – Customers must register before booking.  A demo admin account is created via the seed data with the following credentials:

  - Email: `admin@example.com`
  - Password: `secret` (you should update the hash in `database/schema.sql` with a secure value generated via `password_hash` before deploying)

- **Booking** – Browse villas and packages.  On a detail page click “Book Now” to open the booking form.  Enter dates, number of guests/participants, optionally apply a promo code and choose a payment option (100 %, 75 % or 50 %).  After submission you are redirected to an invoice page showing the payment breakdown and instructions.
- **Payments** – Transfer the required amount via bank transfer or QRIS as displayed.  Use the “Upload Proof” button on the invoice page to upload your payment receipt.  Administrators approve or reject the proof from their dashboard.
- **Admin Panel** – Login to `/admin/login` with an admin account.  From the dashboard you can view bookings, verify payments, manage villas, packages and promo codes.  Create/edit forms allow uploading images and entering multi‑language content.

## Payment Options Explained

Payment options are defined in `config/config.php` under the `payment_options` key:

```php
'payment_options' => [
    'FULL' => 1.00, // Pay 100 % now
    'DP75' => 0.75, // Pay 75 % now, 25 % later
    'DP50' => 0.50, // Pay 50 % now, 50 % later
],
```

When a booking is created the selected option determines `amount_paid_now` and `amount_remaining`.  For example, if the grand total is IDR 10 000 000 and the user selects `DP75`, they pay 7 500 000 up front and the remaining 2 500 000 is due on the specified `due_date_remaining` (typically derived from check‑in date).  Payment statuses progress from `UNPAID` → `PARTIAL` → `PAID` as proofs are approved.  Administrators can configure custom payment percentages by editing this array.

## Discount Calculation

The booking model (`app/Models/BookingModel.php`) applies discounts in the following order:

1. **Promo code** – If the user enters a valid promo code the system checks expiry dates, usage limits, minimum order amounts and whether the code applies to the selected item type.  Percentage codes reduce the subtotal by `(value / 100) × subtotal`; fixed codes subtract a flat amount.  The discount is capped so that it never exceeds the subtotal.
2. **Seasonal rules** – Automatic discounts such as early‑bird or last‑minute can be configured in the `discount_rules` table.  For example, an early‑bird rule might give 10 % off bookings made more than 60 days before the start date.  You can add new rule types (e.g. “low season”) by extending the logic in `BookingModel::calculateDiscount`.

The total discount is stored in `discount_amount` and deducted from the subtotal to obtain the grand total.  Additional discounts are additive but never exceed 100 % of the subtotal.

## Assumptions

- **Currency** – All prices are stored and displayed in Indonesian Rupiah (IDR).  Change the `currency` value in `config/config.php` to adjust the display if needed.
- **Timezone** – The application uses the `Asia/Jakarta` timezone.  Override this via the `TIMEZONE` variable in `.env`.
- **Manual Payments** – Payments are processed manually via bank transfers or QRIS.  No third‑party payment gateway integration is included in this version.  To integrate a gateway you can extend `BookingController::invoice` and `PaymentModel::createPayment`.
- **Security** – For demonstration purposes the admin and user password hashes in the seed data are dummy values.  You **must** generate secure hashes using PHP’s `password_hash()` function before deploying.  Always run the application over HTTPS in production and enable CSRF protection on forms.

## Extending to Other Cities

The data model stores a `city` column on both villas and packages.  To support additional destinations simply insert new records with the appropriate city name.  The front‑end filtering by city (on `/villas` and `/packages`) will automatically pick up new values.  If you need to group cities by region or add categories, consider creating a separate `cities` table and foreign key relationships.

## Changing the Default Language

The default language is defined in `config/config.php` as `default_language => 'id'`.  Changing this value to `'en'` will cause English to be used when no language is selected by the user.  Make sure the selected language exists in `supported_languages` and that corresponding translation files are present under `app/Language/`.

## Running on Shared Hosting

This project is designed for ease of deployment on shared hosting such as cPanel/Hostinger:

1. Upload the contents of the `villa_booking_app` directory to your hosting space.
2. Create a MySQL database and import `database/schema.sql`.
3. Update the `.env` file with your database credentials and base URL (e.g. `https://yourdomain.com/`).
4. Point your domain’s document root to the `villa_booking_app` directory or place `index.php` in a public directory and adjust `base_url` accordingly.
5. Ensure the `uploads/` directory is writable by the web server so that image and proof uploads can be saved.

## Additional Notes

- The **admin** area is mobile‑friendly thanks to simple responsive styling.  Tables scroll horizontally on small screens.
- Email notifications (booking confirmation, payment reminders) are stubbed; you can integrate PHPMailer or a similar library in the future.
- For production systems consider adding CSRF tokens and form validation libraries, caching frequently accessed data, and performing more robust error handling.

Happy bookings and enjoy Bali!